package com.example.jojostands.client;

import com.example.jojostands.JojoStands;
import com.example.jojostands.entity.EntityWaterShot;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;

public class RenderWaterShot extends Render<EntityWaterShot> {
    private static final ResourceLocation WATER = new ResourceLocation(JojoStands.MODID, "textures/entity/water_cube.png");

    public RenderWaterShot(RenderManager m) {
        super(m);
    }

    @Override
    public void doRender(EntityWaterShot e, double x, double y, double z, float yaw, float pt) {
        bindTexture(WATER);
        CubeRender.begin();
        GlStateManager.pushMatrix();
        GlStateManager.translate(x, y + 0.1, z);
        GlStateManager.rotate((e.ticksExisted + pt) * 20.0F, 0.0F, 1.0F, 0.0F);
        CubeRender.draw(0.15F, 1.0F, 1.0F, 1.0F, 0.9F);
        GlStateManager.popMatrix();
        CubeRender.end();
        super.doRender(e, x, y, z, yaw, pt);
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityWaterShot e) {
        return WATER;
    }
}
