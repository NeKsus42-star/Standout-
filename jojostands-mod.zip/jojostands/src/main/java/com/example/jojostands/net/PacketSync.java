package com.example.jojostands.net;

import com.example.jojostands.JojoStands;
import io.netty.buffer.ByteBuf;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class PacketSync implements IMessage {
    public int stand;

    public PacketSync() {}

    public PacketSync(int stand) {
        this.stand = stand;
    }

    @Override
    public void fromBytes(ByteBuf buf) {
        stand = buf.readByte();
    }

    @Override
    public void toBytes(ByteBuf buf) {
        buf.writeByte(stand);
    }

    public static class Handler implements IMessageHandler<PacketSync, IMessage> {
        @Override
        public IMessage onMessage(PacketSync msg, MessageContext ctx) {
            JojoStands.proxy.setClientStand(msg.stand);
            return null;
        }
    }
}
