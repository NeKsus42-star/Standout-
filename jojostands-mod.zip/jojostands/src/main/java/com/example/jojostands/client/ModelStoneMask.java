package com.example.jojostands.client;

import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelRenderer;

/** Каменная маска на персонаже: только лицевая пластина, у висков торчат шипы. */
public class ModelStoneMask extends ModelBiped {
    public ModelStoneMask() {
        super(0.0F, 0.0F, 64, 32);
        this.bipedHead = new ModelRenderer(this, 0, 0);
        this.bipedHeadwear = new ModelRenderer(this, 0, 0);

        ModelRenderer plate = new ModelRenderer(this, 0, 0);
        plate.addBox(-4.0F, -8.0F, -5.0F, 8, 8, 1);
        this.bipedHead.addChild(plate);

        ModelRenderer r1 = new ModelRenderer(this, 0, 10);
        r1.addBox(-7.0F, -6.5F, -4.0F, 3, 1, 1);
        ModelRenderer r2 = new ModelRenderer(this, 0, 10);
        r2.addBox(-6.0F, -4.5F, -3.5F, 2, 1, 1);
        ModelRenderer l1 = new ModelRenderer(this, 0, 10);
        l1.addBox(4.0F, -6.5F, -4.0F, 3, 1, 1);
        ModelRenderer l2 = new ModelRenderer(this, 0, 10);
        l2.addBox(4.0F, -4.5F, -3.5F, 2, 1, 1);
        this.bipedHead.addChild(r1);
        this.bipedHead.addChild(r2);
        this.bipedHead.addChild(l1);
        this.bipedHead.addChild(l2);
    }
}
