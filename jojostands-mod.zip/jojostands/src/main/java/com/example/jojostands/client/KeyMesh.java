package com.example.jojostands.client;

import com.example.jojostands.JojoStands;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.InputStreamReader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.ResourceLocation;

/** Модель ключа (из Mister_president.gltf): треугольники хранятся в models/key_mesh.json, координаты 0..1. */
public class KeyMesh {
    private static final ResourceLocation GOLD = new ResourceLocation(JojoStands.MODID, "textures/entity/key_gold.png");
    private static final ResourceLocation AMETHYST = new ResourceLocation(JojoStands.MODID, "textures/entity/key_amethyst.png");
    private static float[] gold = new float[0];
    private static float[] amethyst = new float[0];
    private static boolean loaded;

    private static float[] toArray(JsonArray a) {
        float[] r = new float[a.size()];
        for (int i = 0; i < r.length; i++) r[i] = a.get(i).getAsFloat();
        return r;
    }

    private static void load() {
        if (loaded) return;
        loaded = true;
        try {
            InputStreamReader in = new InputStreamReader(Minecraft.getMinecraft().getResourceManager()
                    .getResource(new ResourceLocation(JojoStands.MODID, "models/key_mesh.json")).getInputStream(), "UTF-8");
            JsonObject o = new JsonParser().parse(in).getAsJsonObject();
            gold = toArray(o.getAsJsonArray("gold"));
            amethyst = toArray(o.getAsJsonArray("amethyst"));
            in.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /** Рисует ключ: единичный куб с центром в (0.5; 0.5; 0.5). */
    public static void draw() {
        load();
        Minecraft mc = Minecraft.getMinecraft();
        mc.getTextureManager().bindTexture(GOLD);
        tris(gold);
        mc.getTextureManager().bindTexture(AMETHYST);
        tris(amethyst);
    }

    private static void tris(float[] a) {
        if (a.length < 15) return;
        Tessellator t = Tessellator.getInstance();
        BufferBuilder bb = t.getBuffer();
        bb.begin(4, DefaultVertexFormats.POSITION_TEX_NORMAL);
        for (int i = 0; i + 14 < a.length; i += 15) {
            float ux = a[i + 5] - a[i], uy = a[i + 6] - a[i + 1], uz = a[i + 7] - a[i + 2];
            float vx = a[i + 10] - a[i], vy = a[i + 11] - a[i + 1], vz = a[i + 12] - a[i + 2];
            float nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
            float l = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
            if (l < 1.0E-9F) l = 1.0F;
            nx /= l;
            ny /= l;
            nz /= l;
            for (int k = 0; k < 3; k++) {
                int j = i + k * 5;
                bb.pos(a[j], a[j + 1], a[j + 2]).tex(a[j + 3], a[j + 4]).normal(nx, ny, nz).endVertex();
            }
        }
        t.draw();
    }
}
