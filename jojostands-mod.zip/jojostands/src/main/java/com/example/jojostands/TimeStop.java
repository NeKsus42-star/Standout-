package com.example.jojostands;

import com.example.jojostands.entity.EntityStandHand;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityFallingBlock;
import net.minecraft.entity.item.EntityTNTPrimed;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;

/** Star Platinum: зона 15x15x15 вокруг места, где использована способность. */
public class TimeStop {
    public static final double HALF = 7.5;   // 15 блоков в поперечнике
    public static final int DURATION = 100;  // тиков (5 сек)
    public static final int COOLDOWN = 200;  // тиков (10 сек)

    private static class Frozen {
        final Entity e;
        final double x, y, z;
        final float yaw, pitch;
        int fuse = -1, fall;

        Frozen(Entity e) {
            this.e = e;
            x = e.posX; y = e.posY; z = e.posZ;
            yaw = e.rotationYaw; pitch = e.rotationPitch;
            if (e instanceof EntityTNTPrimed) fuse = ((EntityTNTPrimed) e).getFuse();
            if (e instanceof EntityFallingBlock) fall = ((EntityFallingBlock) e).fallTime;
        }
    }

    private static class Stop {
        UUID owner;
        int dim, ticks;
        AxisAlignedBB box;
        Map<UUID, Frozen> frozen = new HashMap<>();
    }

    private static final Map<UUID, Stop> STOPS = new HashMap<>();
    private static final Map<UUID, Long> CD = new HashMap<>();

    private static void msg(EntityPlayer p, String t) {
        p.sendStatusMessage(new TextComponentString(t), true);
    }

    public static void toggle(EntityPlayerMP p) {
        UUID id = p.getUniqueID();
        long now = p.world.getTotalWorldTime();
        if (STOPS.containsKey(id)) {
            STOPS.remove(id);
            CD.put(id, now + COOLDOWN);
            msg(p, "Время возобновило ход");
            return;
        }
        Long until = CD.get(id);
        if (until != null && now < until) {
            msg(p, "Перезарядка: " + ((until - now) / 20 + 1) + " c");
            return;
        }
        Stop s = new Stop();
        s.owner = id;
        s.dim = p.world.provider.getDimension();
        s.ticks = DURATION;
        s.box = new AxisAlignedBB(p.posX - HALF, p.posY - HALF, p.posZ - HALF, p.posX + HALF, p.posY + HALF, p.posZ + HALF);
        STOPS.put(id, s);
        p.world.playSound(null, p.posX, p.posY, p.posZ, SoundEvents.ENTITY_PLAYER_LEVELUP, SoundCategory.PLAYERS, 1.0F, 0.5F);
        msg(p, "ZA WARUDO! Время остановлено");
    }

    /** Начало тика мира: замораживаем всё в зоне. */
    public static void preTick(World w) {
        if (STOPS.isEmpty()) return;
        int dim = w.provider.getDimension();
        for (Stop s : new ArrayList<>(STOPS.values())) {
            if (s.dim != dim) continue;
            EntityPlayer owner = w.getPlayerEntityByUUID(s.owner);
            if (owner == null || owner.isDead || --s.ticks <= 0) {
                STOPS.remove(s.owner);
                CD.put(s.owner, w.getTotalWorldTime() + COOLDOWN);
                if (owner != null) msg(owner, "Время возобновило ход");
                continue;
            }
            for (Entity e : w.getEntitiesWithinAABB(Entity.class, s.box)) {
                if (e == owner || e instanceof EntityPlayer || e instanceof EntityStandHand) continue;
                if (!s.frozen.containsKey(e.getUniqueID())) s.frozen.put(e.getUniqueID(), new Frozen(e));
                e.motionX = 0;
                e.motionY = 0;
                e.motionZ = 0;
            }
        }
    }

    /** Конец тика мира: возвращаем замороженные сущности на место. */
    public static void postTick(World w) {
        if (STOPS.isEmpty()) return;
        int dim = w.provider.getDimension();
        for (Stop s : STOPS.values()) {
            if (s.dim != dim) continue;
            for (Frozen f : s.frozen.values()) {
                Entity e = f.e;
                if (e.isDead) continue;
                e.setPosition(f.x, f.y, f.z);
                e.motionX = 0;
                e.motionY = 0;
                e.motionZ = 0;
                e.rotationYaw = f.yaw;
                e.rotationPitch = f.pitch;
                if (e instanceof EntityTNTPrimed && f.fuse >= 0) ((EntityTNTPrimed) e).setFuse(f.fuse);
                if (e instanceof EntityFallingBlock) ((EntityFallingBlock) e).fallTime = f.fall;
            }
        }
    }

    public static boolean isFrozen(Entity e) {
        if (STOPS.isEmpty()) return false;
        for (Stop s : STOPS.values()) {
            if (s.frozen.containsKey(e.getUniqueID())) return true;
        }
        return false;
    }

    /** Блоки в зоне не получают обновлений (вода, песок, редстоун и т.п.). */
    public static boolean isInside(World w, BlockPos pos) {
        if (STOPS.isEmpty()) return false;
        int dim = w.provider.getDimension();
        Vec3d v = new Vec3d(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5);
        for (Stop s : STOPS.values()) {
            if (s.dim == dim && s.box.contains(v)) return true;
        }
        return false;
    }
}
