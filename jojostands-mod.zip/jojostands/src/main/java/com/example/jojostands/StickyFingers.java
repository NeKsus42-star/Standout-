package com.example.jojostands;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.MobEffects;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

/** Sticky Fingers: голубая молния под игроком, затем телепорт в точку, на которую он смотрел. */
public class StickyFingers {
    private static class Tp {
        Vec3d dest;
        int ticks = 20;
        int dim;
    }

    private static final Map<UUID, Tp> PENDING = new HashMap<>();

    public static void ability(EntityPlayerMP p) {
        if (PENDING.containsKey(p.getUniqueID())) return;
        RayTraceResult r = StandUtil.trace(p, 100.0, e -> false);
        if (r == null || r.typeOfHit != RayTraceResult.Type.BLOCK) {
            StandLogic.msg(p, "Точка не найдена");
            return;
        }
        if (StandLogic.cooldown(p, "sticky", 60)) return;
        BlockPos pos = r.getBlockPos().offset(r.sideHit);
        Tp t = new Tp();
        t.dest = new Vec3d(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5);
        t.dim = p.world.provider.getDimension();
        PENDING.put(p.getUniqueID(), t);
        p.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 25, 7, false, false));
    }

    public static void tick(World w) {
        if (PENDING.isEmpty() || !(w instanceof WorldServer)) return;
        WorldServer ws = (WorldServer) w;
        int dim = w.provider.getDimension();
        for (Map.Entry<UUID, Tp> en : new ArrayList<>(PENDING.entrySet())) {
            Tp t = en.getValue();
            if (t.dim != dim) continue;
            EntityPlayerMP p = (EntityPlayerMP) w.getPlayerEntityByUUID(en.getKey());
            if (p == null || p.isDead) {
                PENDING.remove(en.getKey());
                continue;
            }
            lightning(ws, p.posX, p.posY, p.posZ);
            if (--t.ticks <= 0) {
                PENDING.remove(en.getKey());
                p.connection.setPlayerLocation(t.dest.x, t.dest.y, t.dest.z, p.rotationYaw, p.rotationPitch);
                p.fallDistance = 0.0F;
                lightning(ws, t.dest.x, t.dest.y, t.dest.z);
            }
        }
    }

    private static void lightning(WorldServer ws, double x, double y, double z) {
        double cx = x, cz = z;
        for (double yy = y + 6.0; yy > y - 1.0; yy -= 0.5) {
            cx += (ws.rand.nextDouble() - 0.5) * 0.6;
            cz += (ws.rand.nextDouble() - 0.5) * 0.6;
            ws.spawnParticle(EnumParticleTypes.SPELL_MOB, cx, yy, cz, 0, 0.3, 0.7, 1.0, 1.0);
        }
    }
}
