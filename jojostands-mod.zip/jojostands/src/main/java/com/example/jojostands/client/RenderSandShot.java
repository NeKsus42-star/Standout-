package com.example.jojostands.client;

import com.example.jojostands.entity.EntitySandShot;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;

public class RenderSandShot extends Render<EntitySandShot> {
    private static final ResourceLocation SAND = new ResourceLocation("minecraft", "textures/blocks/sand.png");

    public RenderSandShot(RenderManager m) {
        super(m);
    }

    @Override
    public void doRender(EntitySandShot e, double x, double y, double z, float yaw, float pt) {
        bindTexture(SAND);
        CubeRender.begin();
        GlStateManager.pushMatrix();
        GlStateManager.translate(x, y + 0.2, z);
        GlStateManager.rotate((e.ticksExisted + pt) * 40.0F, 0.0F, 1.0F, 0.3F);
        CubeRender.draw(0.22F, 1.0F, 1.0F, 1.0F, 1.0F);
        GlStateManager.popMatrix();
        CubeRender.end();
        super.doRender(e, x, y, z, yaw, pt);
    }

    @Override
    protected ResourceLocation getEntityTexture(EntitySandShot e) {
        return SAND;
    }
}
