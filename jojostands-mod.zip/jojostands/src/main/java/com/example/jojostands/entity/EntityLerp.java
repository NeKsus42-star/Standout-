package com.example.jojostands.entity;

import net.minecraft.entity.Entity;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

/** Базовая сущность без сохранения с плавной интерполяцией позиции на клиенте. */
public abstract class EntityLerp extends Entity {
    private double lx, ly, lz;
    private int steps;

    public EntityLerp(World w) {
        super(w);
    }

    @Override
    protected void entityInit() {}

    @Override
    protected void readEntityFromNBT(NBTTagCompound c) {}

    @Override
    protected void writeEntityToNBT(NBTTagCompound c) {}

    @SideOnly(Side.CLIENT)
    @Override
    public void setPositionAndRotationDirect(double x, double y, double z, float yaw, float pitch, int inc, boolean teleport) {
        lx = x;
        ly = y;
        lz = z;
        rotationYaw = yaw;
        rotationPitch = pitch;
        steps = 3;
    }

    protected void lerpClient() {
        if (steps > 0) {
            double nx = posX + (lx - posX) / steps;
            double ny = posY + (ly - posY) / steps;
            double nz = posZ + (lz - posZ) / steps;
            steps--;
            setPosition(nx, ny, nz);
        }
    }
}
