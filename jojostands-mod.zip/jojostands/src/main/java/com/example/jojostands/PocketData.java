package com.example.jojostands;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.nbt.NBTTagLong;
import net.minecraft.world.World;
import net.minecraft.world.storage.MapStorage;
import net.minecraft.world.storage.WorldSavedData;

/** Данные карманного измерения: домики игроков и блоки, которые игроки поставили сами. */
public class PocketData extends WorldSavedData {
    public static final String ID = "jojostands_pocket";
    public final Map<String, Integer> slots = new HashMap<>();
    public final Set<Integer> built = new HashSet<>();
    public final Set<Long> placed = new HashSet<>();
    public int next;

    public PocketData() {
        super(ID);
    }

    public PocketData(String name) {
        super(name);
    }

    @Override
    public void readFromNBT(NBTTagCompound nbt) {
        next = nbt.getInteger("next");
        NBTTagCompound s = nbt.getCompoundTag("slots");
        for (String k : s.getKeySet()) slots.put(k, s.getInteger(k));
        for (int v : nbt.getIntArray("built")) built.add(v);
        NBTTagList l = nbt.getTagList("placed", 4);
        for (int i = 0; i < l.tagCount(); i++) placed.add(((NBTTagLong) l.get(i)).getLong());
    }

    @Override
    public NBTTagCompound writeToNBT(NBTTagCompound nbt) {
        nbt.setInteger("next", next);
        NBTTagCompound s = new NBTTagCompound();
        for (Map.Entry<String, Integer> e : slots.entrySet()) s.setInteger(e.getKey(), e.getValue());
        nbt.setTag("slots", s);
        int[] b = new int[built.size()];
        int i = 0;
        for (int v : built) b[i++] = v;
        nbt.setIntArray("built", b);
        NBTTagList l = new NBTTagList();
        for (long v : placed) l.appendTag(new NBTTagLong(v));
        nbt.setTag("placed", l);
        return nbt;
    }

    public int slotFor(String uuid) {
        Integer s = slots.get(uuid);
        if (s == null) {
            s = next++;
            slots.put(uuid, s);
            markDirty();
        }
        return s;
    }

    public static PocketData get(World w) {
        MapStorage st = w.getPerWorldStorage();
        PocketData d = (PocketData) st.getOrLoadData(PocketData.class, ID);
        if (d == null) {
            d = new PocketData();
            st.setData(ID, d);
        }
        return d;
    }
}
