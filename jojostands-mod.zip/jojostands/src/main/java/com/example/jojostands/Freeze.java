package com.example.jojostands;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.entity.Entity;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

/** Заморозка отдельных существ (способность вампира). */
public class Freeze {
    private static class F {
        Entity e;
        double x, y, z;
        int ticks;
    }

    private static final Map<UUID, F> MAP = new HashMap<>();

    public static void freeze(Entity e, int ticks) {
        F f = new F();
        f.e = e;
        f.x = e.posX;
        f.y = e.posY;
        f.z = e.posZ;
        f.ticks = ticks;
        e.setNoGravity(true);
        MAP.put(e.getUniqueID(), f);
    }

    public static boolean isFrozen(Entity e) {
        return !MAP.isEmpty() && MAP.containsKey(e.getUniqueID());
    }

    public static void postTick(World w) {
        if (MAP.isEmpty() || !(w instanceof WorldServer)) return;
        for (F f : new ArrayList<>(MAP.values())) {
            Entity e = f.e;
            if (e.world != w) continue;
            if (e.isDead || --f.ticks <= 0) {
                MAP.remove(e.getUniqueID());
                if (!e.isDead) e.setNoGravity(false);
                continue;
            }
            e.setPosition(f.x, f.y, f.z);
            e.motionX = 0;
            e.motionY = 0;
            e.motionZ = 0;
            if (e.ticksExisted % 5 == 0) {
                ((WorldServer) w).spawnParticle(EnumParticleTypes.SNOW_SHOVEL, e.posX, e.posY + e.height / 2, e.posZ, 4, 0.3, 0.4, 0.3, 0.02);
            }
        }
    }
}
