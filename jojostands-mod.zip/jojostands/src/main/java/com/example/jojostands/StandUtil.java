package com.example.jojostands;

import java.util.function.Predicate;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;

public class StandUtil {
    /** Луч из глаз игрока: ближайшая подходящая сущность или блок. */
    public static RayTraceResult trace(EntityPlayer p, double range, Predicate<Entity> filter) {
        Vec3d eye = p.getPositionEyes(1.0F);
        Vec3d look = p.getLook(1.0F);
        Vec3d end = eye.addVector(look.x * range, look.y * range, look.z * range);
        RayTraceResult blk = p.world.rayTraceBlocks(eye, end, false, true, false);
        double best = blk != null ? blk.hitVec.distanceTo(eye) : range;
        Entity hit = null;
        Vec3d hitVec = null;
        AxisAlignedBB area = p.getEntityBoundingBox().expand(look.x * range, look.y * range, look.z * range).grow(1.0);
        for (Entity e : p.world.getEntitiesWithinAABBExcludingEntity(p, area)) {
            if (!filter.test(e)) continue;
            AxisAlignedBB bb = e.getEntityBoundingBox().grow(e.getCollisionBorderSize() + 0.25);
            double d;
            Vec3d v;
            if (bb.contains(eye)) {
                d = 0;
                v = eye;
            } else {
                RayTraceResult r = bb.calculateIntercept(eye, end);
                if (r == null) continue;
                v = r.hitVec;
                d = eye.distanceTo(v);
            }
            if (d < best) {
                best = d;
                hit = e;
                hitVec = v;
            }
        }
        if (hit != null) return new RayTraceResult(hit, hitVec);
        return blk;
    }

    public static Vec3d center(Entity e) {
        return new Vec3d(e.posX, e.posY + e.height / 2.0, e.posZ);
    }
}
