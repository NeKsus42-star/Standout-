package com.example.jojostands;

import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.init.Biomes;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.gen.IChunkGenerator;
import net.minecraftforge.fml.common.IWorldGenerator;

/** Засушенные деревья (только в пустыне), иногда на ветках висят плодовые блоки. */
public class WorldGenDesert implements IWorldGenerator {
    @Override
    public void generate(Random rand, int chunkX, int chunkZ, World world, IChunkGenerator gen, IChunkProvider prov) {
        if (world.provider.getDimension() != 0) return;
        for (int i = 0; i < 2; i++) {
            if (rand.nextInt(5) != 0) continue;
            int x = chunkX * 16 + 10 + rand.nextInt(12);
            int z = chunkZ * 16 + 10 + rand.nextInt(12);
            BlockPos top = world.getTopSolidOrLiquidBlock(new BlockPos(x, 0, z));
            Biome b = world.getBiome(top);
            if (b != Biomes.DESERT && b != Biomes.DESERT_HILLS && b != Biomes.MUTATED_DESERT) continue;
            if (world.getBlockState(top.down()).getMaterial() != Material.SAND) continue;

            int h = 4 + rand.nextInt(3);
            for (int y = 0; y < h; y++) place(world, top.up(y), false);

            int branches = 2 + rand.nextInt(2);
            for (int k = 0; k < branches; k++) {
                EnumFacing f = EnumFacing.Plane.HORIZONTAL.random(rand);
                BlockPos bp = top.up(2 + rand.nextInt(h - 2));
                int len = 1 + rand.nextInt(2);
                for (int l = 0; l < len; l++) {
                    bp = bp.offset(f);
                    place(world, bp, false);
                }
                if (rand.nextInt(3) == 0) place(world, bp.down(), true);
            }
        }
    }

    private static void place(World w, BlockPos pos, boolean fruit) {
        if (!w.isAirBlock(pos)) return;
        w.setBlockState(pos, (fruit ? ModContent.FRUIT_BLOCK : ModContent.DRIED_WOOD).getDefaultState(), 2);
    }
}
