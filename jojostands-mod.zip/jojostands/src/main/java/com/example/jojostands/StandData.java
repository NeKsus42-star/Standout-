package com.example.jojostands;

import com.example.jojostands.net.ModNetwork;
import com.example.jojostands.net.PacketSync;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.text.TextComponentString;

public class StandData {
    public static final int NONE = 0, KILLER_QUEEN = 1, STAR_PLATINUM = 2, GOLD_EXPERIENCE = 3;
    public static final String[] NAMES = {"", "Killer Queen", "Star Platinum", "Gold Experience"};
    private static final String KEY = "jojostand";

    public static int get(EntityPlayer p) {
        NBTTagCompound d = p.getEntityData();
        if (!d.hasKey(EntityPlayer.PERSISTED_NBT_TAG, 10)) return 0;
        return d.getCompoundTag(EntityPlayer.PERSISTED_NBT_TAG).getInteger(KEY);
    }

    public static void setRaw(EntityPlayer p, int type) {
        NBTTagCompound d = p.getEntityData();
        NBTTagCompound persisted = d.getCompoundTag(EntityPlayer.PERSISTED_NBT_TAG);
        persisted.setInteger(KEY, type);
        d.setTag(EntityPlayer.PERSISTED_NBT_TAG, persisted);
    }

    public static void set(EntityPlayer p, int type) {
        setRaw(p, type);
        if (p instanceof EntityPlayerMP) sync((EntityPlayerMP) p);
    }

    public static void sync(EntityPlayerMP p) {
        ModNetwork.CHANNEL.sendTo(new PacketSync(get(p)), p);
    }

    public static void grantRandom(EntityPlayer p) {
        int type = 1 + p.getRNG().nextInt(3);
        set(p, type);
        p.sendMessage(new TextComponentString("Вы получили стенд: " + NAMES[type]
                + "! R - вызвать/убрать руку. Кнопки удара, способности и захвата предметов назначьте в настройках управления."));
    }
}
