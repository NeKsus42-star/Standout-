package com.example.jojostands.entity;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.projectile.EntityThrowable;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

/** Блок воды, выпущенный Geb. */
public class EntityWaterShot extends EntityThrowable {
    private float damage = 5.0F;

    public EntityWaterShot(World w) {
        super(w);
    }

    public EntityWaterShot(World w, EntityLivingBase thrower, float damage) {
        super(w, thrower);
        this.damage = damage;
    }

    @Override
    protected float getGravityVelocity() {
        return 0.01F;
    }

    @Override
    public void onUpdate() {
        super.onUpdate();
        if (world.isRemote) {
            world.spawnParticle(EnumParticleTypes.WATER_SPLASH, posX, posY, posZ, 0, 0, 0);
        } else if (!isDead && ticksExisted > 60) {
            setDead();
        }
    }

    @Override
    protected void onImpact(RayTraceResult r) {
        if (world.isRemote) return;
        if (r.entityHit != null) {
            r.entityHit.attackEntityFrom(DamageSource.causeThrownDamage(this, getThrower()), damage);
            r.entityHit.extinguish();
        }
        ((WorldServer) world).spawnParticle(EnumParticleTypes.WATER_SPLASH, posX, posY, posZ, 12, 0.3, 0.3, 0.3, 0.1);
        setDead();
    }
}
