package com.example.jojostands;

import com.example.jojostands.entity.EntityStandHand;
import com.example.jojostands.entity.EntityWaterShot;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

/**
 * Geb: вода вращается вокруг игрока. Берётся из блоков растительного происхождения
 * (листва, трава, цветы, кактус, тыквы...) и из источников воды рядом. В пустыне без кактусов бесполезен.
 */
public class Geb {
    public static final int MAX = 10;
    public static final int RADIUS = 5;
    public static final int STREAM_COST = 4;
    public static final int DOME_COST = 5;
    public static final int FORM_TICKS = 300;   // 15 секунд
    public static final int FORM_COOLDOWN = 600;

    private static class Form {
        EntityStandHand hand;
        int ticks = FORM_TICKS;
        int dim;
    }

    private static class Dome {
        int ticks = 20;
        int dim;
    }

    private static final Map<UUID, Form> FORMS = new HashMap<>();
    private static final Map<UUID, Dome> DOMES = new HashMap<>();

    // ---------------- набор воды ----------------
    private static boolean isWaterSource(IBlockState st) {
        if (st.getBlock() == Blocks.WATER || st.getBlock() == Blocks.FLOWING_WATER) {
            return st.getValue(BlockLiquid.LEVEL) == 0;
        }
        return false;
    }

    private static boolean isPlant(IBlockState st) {
        if (st.getBlock() == Blocks.DEADBUSH) return false;
        Material m = st.getMaterial();
        return m == Material.PLANTS || m == Material.LEAVES || m == Material.VINE || m == Material.CACTUS || m == Material.GOURD;
    }

    /** Забирает один подходящий блок рядом с игроком и добавляет заряд воды. */
    public static boolean absorb(EntityStandHand hand, EntityPlayer owner) {
        World w = owner.world;
        BlockPos c = owner.getPosition();
        BlockPos best = null;
        double bd = Double.MAX_VALUE;
        for (int dx = -RADIUS; dx <= RADIUS; dx++) {
            for (int dy = -3; dy <= RADIUS; dy++) {
                for (int dz = -RADIUS; dz <= RADIUS; dz++) {
                    BlockPos pos = c.add(dx, dy, dz);
                    IBlockState st = w.getBlockState(pos);
                    if (!isWaterSource(st) && !isPlant(st)) continue;
                    double d = dx * dx + dy * dy + dz * dz;
                    if (d < bd) {
                        bd = d;
                        best = pos;
                    }
                }
            }
        }
        if (best == null) return false;
        w.setBlockToAir(best);
        hand.setCharges(hand.getCharges() + 1);

        WorldServer ws = (WorldServer) w;
        double fx = best.getX() + 0.5, fy = best.getY() + 0.5, fz = best.getZ() + 0.5;
        double dx = owner.posX - fx, dy = owner.posY + 1.0 - fy, dz = owner.posZ - fz;
        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        int n = Math.max(1, (int) (len / 0.6));
        for (int i = 0; i <= n; i++) {
            double t = (double) i / n;
            ws.spawnParticle(EnumParticleTypes.SPELL_MOB, fx + dx * t, fy + dy * t, fz + dz * t, 0, 0.1, 0.4, 1.0, 1.0);
        }
        return true;
    }

    // ---------------- выстрел (вместо удара) ----------------
    public static void shoot(EntityPlayerMP p, EntityStandHand hand) {
        int ch = hand.getCharges();
        if (ch <= 0) {
            StandLogic.msg(p, "Нет воды: нужны растения или источники воды рядом");
            return;
        }
        if (StandLogic.cooldown(p, "gebshot", 8)) return;
        int n = ch >= STREAM_COST ? STREAM_COST : 1; // струя из блоков, если хватает воды
        hand.setCharges(ch - n);
        Vec3d look = p.getLookVec();
        for (int i = 0; i < n; i++) {
            EntityWaterShot s = new EntityWaterShot(p.world, p, 5.0F);
            s.setPosition(s.posX - look.x * 0.7 * i, s.posY - look.y * 0.7 * i, s.posZ - look.z * 0.7 * i);
            s.shoot(p, p.rotationPitch, p.rotationYaw, 0.0F, 1.8F, 0.0F);
            p.world.spawnEntity(s);
        }
        p.world.playSound(null, p.posX, p.posY, p.posZ, SoundEvents.ENTITY_GENERIC_SPLASH, SoundCategory.PLAYERS, 0.8F, 1.2F);
    }

    // ---------------- купол (вместо захвата) ----------------
    public static void dome(EntityPlayerMP p, EntityStandHand hand) {
        int ch = hand.getCharges();
        if (ch < DOME_COST) {
            StandLogic.msg(p, "Для купола нужно воды: " + DOME_COST);
            return;
        }
        if (DOMES.containsKey(p.getUniqueID())) return;
        if (StandLogic.cooldown(p, "gebdome", 100)) return;
        hand.setCharges(ch - DOME_COST);
        Dome d = new Dome();
        d.dim = p.world.provider.getDimension();
        DOMES.put(p.getUniqueID(), d);
    }

    // ---------------- ульта: превращение в воду ----------------
    public static void ult(EntityPlayerMP p, EntityStandHand hand) {
        Form f = FORMS.get(p.getUniqueID());
        if (f != null) {
            endForm(p, f);
            return;
        }
        if (StandLogic.cooldown(p, "gebult", FORM_COOLDOWN)) return;
        f = new Form();
        f.hand = hand;
        f.dim = p.world.provider.getDimension();
        FORMS.put(p.getUniqueID(), f);
        hand.setForm(true);
        p.addPotionEffect(new PotionEffect(MobEffects.INVISIBILITY, FORM_TICKS, 0, false, false));
        p.addPotionEffect(new PotionEffect(MobEffects.SPEED, FORM_TICKS, 2, false, false));
        StandLogic.msg(p, "Вы стали водой. В воде бегите (спринт) - ускорение");
    }

    private static void endForm(EntityPlayer p, Form f) {
        FORMS.remove(p.getUniqueID());
        f.hand.setForm(false);
        p.removePotionEffect(MobEffects.INVISIBILITY);
        p.removePotionEffect(MobEffects.SPEED);
    }

    // ---------------- тики ----------------
    public static void tick(World w) {
        if (!(w instanceof WorldServer)) return;
        if (FORMS.isEmpty() && DOMES.isEmpty()) return;
        WorldServer ws = (WorldServer) w;
        int dim = w.provider.getDimension();

        for (Map.Entry<UUID, Form> en : new ArrayList<>(FORMS.entrySet())) {
            Form f = en.getValue();
            if (f.dim != dim) continue;
            EntityPlayer p = w.getPlayerEntityByUUID(en.getKey());
            if (p == null) {
                FORMS.remove(en.getKey());
                f.hand.setForm(false);
                continue;
            }
            if (p.isDead || f.hand.isDead || --f.ticks <= 0) {
                endForm(p, f);
                continue;
            }
            if (p.isInWater() && p.isSprinting()) { // в воде быстро
                Vec3d l = p.getLookVec();
                p.motionX += l.x * 0.12;
                p.motionY += l.y * 0.12;
                p.motionZ += l.z * 0.12;
                p.velocityChanged = true;
            }
            if (p.ticksExisted % 10 == 0) { // 2.5 сердца в секунду = 5 хп/с
                for (EntityLivingBase e : w.getEntitiesWithinAABB(EntityLivingBase.class, p.getEntityBoundingBox().grow(0.2))) {
                    if (e == p) continue;
                    e.hurtResistantTime = 0;
                    e.attackEntityFrom(DamageSource.causePlayerDamage(p), 2.5F);
                }
            }
            if (p.ticksExisted % 2 == 0) {
                ws.spawnParticle(EnumParticleTypes.WATER_SPLASH, p.posX, p.posY + 0.9, p.posZ, 6, 0.4, 0.6, 0.4, 0.05);
            }
        }

        for (Map.Entry<UUID, Dome> en : new ArrayList<>(DOMES.entrySet())) {
            Dome d = en.getValue();
            if (d.dim != dim) continue;
            EntityPlayer p = w.getPlayerEntityByUUID(en.getKey());
            if (p == null || p.isDead) {
                DOMES.remove(en.getKey());
                continue;
            }
            for (int i = 0; i < 25; i++) { // оболочка купола
                double u = ws.rand.nextDouble() * Math.PI;
                double a = ws.rand.nextDouble() * Math.PI * 2;
                double r = 2.6;
                ws.spawnParticle(EnumParticleTypes.SPELL_MOB, p.posX + Math.sin(u) * Math.cos(a) * r, p.posY + 1.0 + Math.cos(u) * r,
                        p.posZ + Math.sin(u) * Math.sin(a) * r, 0, 0.1, 0.4, 1.0, 1.0);
            }
            if (--d.ticks <= 0) {
                DOMES.remove(en.getKey());
                for (int i = 0; i < 24; i++) { // выстрел водой во все стороны
                    double vx = ws.rand.nextGaussian(), vy = ws.rand.nextGaussian(), vz = ws.rand.nextGaussian();
                    EntityWaterShot s = new EntityWaterShot(w, p, 3.0F);
                    s.setPosition(p.posX, p.posY + 1.0, p.posZ);
                    s.shoot(vx, vy, vz, 1.4F, 0.0F);
                    w.spawnEntity(s);
                }
                w.playSound(null, p.posX, p.posY, p.posZ, SoundEvents.ENTITY_GENERIC_SPLASH, SoundCategory.PLAYERS, 1.2F, 0.8F);
            }
        }
    }
}
