package com.example.jojostands;

import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityShulker;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.world.WorldServer;

/** Вампиризм: даётся за убийство моба в каменной маске. Клавиши удара/захвата/способности меняют действие. */
public class Vampire {
    private static final String KEY = "jojovampire";
    public static final int EFFECT_TICKS = 1200;  // 1 минута
    public static final int FREEZE_TICKS = 200;   // 10 секунд

    public static boolean isVampire(EntityPlayer p) {
        NBTTagCompound d = p.getEntityData();
        return d.hasKey(EntityPlayer.PERSISTED_NBT_TAG, 10) && d.getCompoundTag(EntityPlayer.PERSISTED_NBT_TAG).getBoolean(KEY);
    }

    public static void setVampire(EntityPlayer p, boolean v) {
        NBTTagCompound d = p.getEntityData();
        NBTTagCompound per = d.getCompoundTag(EntityPlayer.PERSISTED_NBT_TAG);
        per.setBoolean(KEY, v);
        d.setTag(EntityPlayer.PERSISTED_NBT_TAG, per);
    }

    /** 0 - нет маски, 1 - каменная маска, 2 - маска с камнем */
    public static int mask(EntityPlayer p) {
        ItemStack s = p.getItemStackFromSlot(EntityEquipmentSlot.HEAD);
        if (s.getItem() == ModContent.STONE_MASK) return 1;
        if (s.getItem() == ModContent.STONE_MASK_EISHA) return 2;
        return 0;
    }

    public static boolean active(EntityPlayer p) {
        return mask(p) > 0 && isVampire(p);
    }

    public static void handle(EntityPlayerMP p, int action) {
        if (action == 1) punch(p);
        else if (action == 2) {
            if (mask(p) == 2) parody(p);
            else Lasers.start(p);
        } else if (action == 3) freeze(p);
    }

    private static void punch(EntityPlayerMP p) {
        RayTraceResult r = StandUtil.trace(p, 4.5, e -> e instanceof EntityLivingBase);
        if (r == null || r.entityHit == null) {
            StandLogic.msg(p, "Нет цели");
            return;
        }
        if (StandLogic.cooldown(p, "vpunch", 12)) return;
        EntityLivingBase t = (EntityLivingBase) r.entityHit;
        t.attackEntityFrom(DamageSource.causePlayerDamage(p), 9.0F);
        p.heal(3.0F);
        t.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, EFFECT_TICKS, 1));
        ((WorldServer) p.world).spawnParticle(EnumParticleTypes.REDSTONE, t.posX, t.posY + t.height / 2, t.posZ, 25, 0.4, 0.5, 0.4, 0.0);
        p.world.playSound(null, t.posX, t.posY, t.posZ, SoundEvents.ENTITY_PLAYER_ATTACK_STRONG, SoundCategory.PLAYERS, 1.0F, 0.7F);
    }

    private static void freeze(EntityPlayerMP p) {
        RayTraceResult r = StandUtil.trace(p, 30.0, e -> e instanceof EntityLivingBase);
        if (r == null || r.entityHit == null) {
            StandLogic.msg(p, "Нет цели");
            return;
        }
        if (StandLogic.cooldown(p, "vfreeze", 100)) return;
        EntityLivingBase t = (EntityLivingBase) r.entityHit;
        if (t.height <= 2.0F && t.width <= 0.8F) {
            // небольшие мобы (как жители): поднимаем на 2 блока вверх и замораживаем
            t.setPositionAndUpdate(t.posX, t.posY + 2.0, t.posZ);
            Freeze.freeze(t, FREEZE_TICKS);
        } else {
            // крупные: замораживаем всех в области 4x4
            AxisAlignedBB box = new AxisAlignedBB(t.posX - 2, t.posY - 1, t.posZ - 2, t.posX + 2, t.posY + 3, t.posZ + 2);
            for (EntityLivingBase e : p.world.getEntitiesWithinAABB(EntityLivingBase.class, box)) {
                if (e != p && !(e instanceof EntityPlayer)) Freeze.freeze(e, FREEZE_TICKS);
            }
        }
    }

    /** Пародия (маска с камнем): эффект зависит от того, на что наведён курсор. */
    private static void parody(EntityPlayerMP p) {
        RayTraceResult r = StandUtil.trace(p, 30.0, e -> e instanceof EntityLivingBase);
        if (r == null) {
            StandLogic.msg(p, "Наведите курсор на блок или моба");
            return;
        }
        if (StandLogic.cooldown(p, "parody", 100)) return;
        if (r.entityHit instanceof EntityShulker) {
            // в 1.12.2 нет черепах: панцирь шалкера даёт полную неуязвимость
            p.addPotionEffect(new PotionEffect(MobEffects.RESISTANCE, EFFECT_TICKS, 4));
            StandLogic.msg(p, "Панцирь: полная неуязвимость к урону");
        } else if (r.entityHit != null) {
            p.addPotionEffect(new PotionEffect(MobEffects.REGENERATION, EFFECT_TICKS, 1));
            StandLogic.msg(p, "Регенерация");
        } else {
            BlockPos pos = r.getBlockPos();
            IBlockState st = p.world.getBlockState(pos);
            float h = st.getBlockHardness(p.world, pos);
            int amp = h < 1.5F ? 0 : h < 3.0F ? 1 : h < 5.0F ? 2 : 3; // от камня до железа сопротивление растёт
            p.addPotionEffect(new PotionEffect(MobEffects.RESISTANCE, EFFECT_TICKS, amp));
            StandLogic.msg(p, "Сопротивление " + (amp + 1));
        }
    }
}
