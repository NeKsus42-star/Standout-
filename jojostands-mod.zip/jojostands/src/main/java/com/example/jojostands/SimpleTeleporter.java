package com.example.jojostands;

import net.minecraft.entity.Entity;
import net.minecraft.world.World;
import net.minecraftforge.common.util.ITeleporter;

public class SimpleTeleporter implements ITeleporter {
    private final double x, y, z;

    public SimpleTeleporter(double x, double y, double z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    @Override
    public void placeEntity(World world, Entity entity, float yaw) {
        entity.motionX = 0;
        entity.motionY = 0;
        entity.motionZ = 0;
        entity.fallDistance = 0.0F;
        entity.setLocationAndAngles(x, y, z, yaw, entity.rotationPitch);
    }
}
