package com.example.jojostands;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockMeteor extends Block {
    public BlockMeteor() {
        super(Material.ROCK);
        setRegistryName(JojoStands.MODID, "meteor_block");
        setUnlocalizedName("meteor_block");
        setHardness(6.0F);
        setResistance(20.0F);
        setHarvestLevel("pickaxe", 2); // 2 = железная кирка
        setSoundType(SoundType.STONE);
        setLightLevel(0.4F);
        setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
    }

    /** Без железной (или лучше) кирки блок вообще не ломается. */
    @Override
    public float getPlayerRelativeBlockHardness(IBlockState state, EntityPlayer player, World world, BlockPos pos) {
        ItemStack held = player.getHeldItemMainhand();
        if (!player.capabilities.isCreativeMode && held.getItem().getHarvestLevel(held, "pickaxe", player, state) < 2) {
            return 0.0F;
        }
        return super.getPlayerRelativeBlockHardness(state, player, world, pos);
    }

    @Override
    public Item getItemDropped(IBlockState state, Random rand, int fortune) {
        return ModContent.METEOR_SHARD;
    }

    @Override
    public int quantityDropped(Random random) {
        return 2 + random.nextInt(3);
    }
}
