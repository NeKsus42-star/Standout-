package com.example.jojostands;

import net.minecraft.block.BlockBed;
import net.minecraft.block.BlockChest;
import net.minecraft.block.BlockHorizontal;
import net.minecraft.block.BlockTorch;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.DimensionType;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.common.DimensionManager;

/** Карманное измерение: у каждого игрока свой деревянный домик. Ломать можно только то, что поставил сам. */
public class PocketDimension {
    public static final int DIM_ID = 135;
    public static DimensionType TYPE;

    public static void register() {
        TYPE = DimensionType.register("jojo_pocket", "_pocket", DIM_ID, WorldProviderPocket.class, false);
        DimensionManager.registerDimension(DIM_ID, TYPE);
    }

    private static BlockPos origin(int slot) {
        return new BlockPos(slot * 32, 64, 0);
    }

    public static void enter(EntityPlayerMP p) {
        MinecraftServer server = p.getServer();
        if (server == null) return;
        WorldServer pw = server.getWorld(DIM_ID);
        PocketData data = PocketData.get(pw);
        int slot = data.slotFor(p.getUniqueID().toString());
        BlockPos o = origin(slot);
        if (!data.built.contains(slot)) {
            build(pw, o);
            data.built.add(slot);
            data.markDirty();
        }
        NBTTagCompound d = p.getEntityData();
        NBTTagCompound per = d.getCompoundTag(net.minecraft.entity.player.EntityPlayer.PERSISTED_NBT_TAG);
        per.setInteger("pocketRetDim", p.world.provider.getDimension());
        per.setDouble("pocketRetX", p.posX);
        per.setDouble("pocketRetY", p.posY);
        per.setDouble("pocketRetZ", p.posZ);
        d.setTag(net.minecraft.entity.player.EntityPlayer.PERSISTED_NBT_TAG, per);
        StandLogic.msg(p, "Вы в карманном измерении");
        p.changeDimension(DIM_ID, new SimpleTeleporter(o.getX() + 3.5, o.getY(), o.getZ() + 2.5));
    }

    public static void leave(EntityPlayerMP p) {
        MinecraftServer server = p.getServer();
        if (server == null) return;
        NBTTagCompound per = p.getEntityData().getCompoundTag(net.minecraft.entity.player.EntityPlayer.PERSISTED_NBT_TAG);
        int dim = 0;
        double x, y, z;
        if (per.hasKey("pocketRetX")) {
            dim = per.getInteger("pocketRetDim");
            x = per.getDouble("pocketRetX");
            y = per.getDouble("pocketRetY");
            z = per.getDouble("pocketRetZ");
        } else {
            BlockPos sp = server.getWorld(0).getSpawnPoint();
            x = sp.getX() + 0.5;
            y = sp.getY();
            z = sp.getZ() + 0.5;
        }
        StandLogic.msg(p, "Вы вернулись");
        p.changeDimension(dim, new SimpleTeleporter(x, y, z));
    }

    // ---------------- домик ----------------
    private static void set(World w, BlockPos p, IBlockState s) {
        w.setBlockState(p, s, 2);
    }

    /** Интерьер 7x4x7: брёвна по углам, книжные полки, кровать, сундук, окно, факелы. */
    private static void build(World w, BlockPos o) {
        IBlockState planks = Blocks.PLANKS.getDefaultState();
        IBlockState air = Blocks.AIR.getDefaultState();
        int ox = o.getX(), oy = o.getY(), oz = o.getZ();
        for (int x = -1; x <= 7; x++) {
            for (int y = -1; y <= 4; y++) {
                for (int z = -1; z <= 7; z++) {
                    boolean shell = x == -1 || x == 7 || y == -1 || y == 4 || z == -1 || z == 7;
                    set(w, new BlockPos(ox + x, oy + y, oz + z), shell ? planks : air);
                }
            }
        }
        IBlockState log = Blocks.LOG.getDefaultState();
        for (int y = -1; y <= 4; y++) {
            for (int cx : new int[]{-1, 7}) {
                for (int cz : new int[]{-1, 7}) set(w, new BlockPos(ox + cx, oy + y, oz + cz), log);
            }
        }
        // книжные полки вдоль западной и восточной стен (2 в высоту)
        for (int z = 1; z <= 5; z++) {
            for (int y = 0; y <= 1; y++) {
                set(w, new BlockPos(ox, oy + y, oz + z), Blocks.BOOKSHELF.getDefaultState());
                set(w, new BlockPos(ox + 6, oy + y, oz + z), Blocks.BOOKSHELF.getDefaultState());
            }
        }
        // окно в северной стене
        for (int x = 2; x <= 4; x++) {
            for (int y = 1; y <= 2; y++) set(w, new BlockPos(ox + x, oy + y, oz - 1), Blocks.GLASS_PANE.getDefaultState());
        }
        // кровать у южной стены (изголовьем к стене)
        IBlockState foot = Blocks.BED.getDefaultState().withProperty(BlockBed.PART, BlockBed.EnumPartType.FOOT)
                .withProperty(BlockHorizontal.FACING, EnumFacing.SOUTH);
        IBlockState head = Blocks.BED.getDefaultState().withProperty(BlockBed.PART, BlockBed.EnumPartType.HEAD)
                .withProperty(BlockHorizontal.FACING, EnumFacing.SOUTH);
        set(w, new BlockPos(ox + 3, oy, oz + 5), foot);
        set(w, new BlockPos(ox + 3, oy, oz + 6), head);
        // сундук и верстак
        set(w, new BlockPos(ox + 1, oy, oz), Blocks.CHEST.getDefaultState().withProperty(BlockChest.FACING, EnumFacing.SOUTH));
        set(w, new BlockPos(ox + 5, oy, oz), Blocks.CRAFTING_TABLE.getDefaultState());
        // факелы на стенах
        set(w, new BlockPos(ox, oy + 2, oz + 3), Blocks.TORCH.getDefaultState().withProperty(BlockTorch.FACING, EnumFacing.EAST));
        set(w, new BlockPos(ox + 6, oy + 2, oz + 3), Blocks.TORCH.getDefaultState().withProperty(BlockTorch.FACING, EnumFacing.WEST));
        set(w, new BlockPos(ox + 3, oy + 2, oz), Blocks.TORCH.getDefaultState().withProperty(BlockTorch.FACING, EnumFacing.SOUTH));
        set(w, new BlockPos(ox + 1, oy + 2, oz + 6), Blocks.TORCH.getDefaultState().withProperty(BlockTorch.FACING, EnumFacing.NORTH));
        set(w, new BlockPos(ox + 5, oy + 2, oz + 6), Blocks.TORCH.getDefaultState().withProperty(BlockTorch.FACING, EnumFacing.NORTH));
    }
}
