package com.example.jojostands.client;

import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.tileentity.TileEntityItemStackRenderer;
import net.minecraft.item.ItemStack;

/** Рисует предмет "Ключ" его 3D-моделью (в руке, в GUI, на земле). */
public class TeisrKey extends TileEntityItemStackRenderer {
    private void renderKey() {
        GlStateManager.pushMatrix();
        GlStateManager.disableCull();
        GlStateManager.enableRescaleNormal();
        KeyMesh.draw();
        GlStateManager.enableCull();
        GlStateManager.popMatrix();
    }

    public void renderByItem(ItemStack stack) {
        renderKey();
    }

    public void renderByItem(ItemStack stack, float partialTicks) {
        renderKey();
    }
}
