package com.example.jojostands;

import net.minecraft.block.Block;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = JojoStands.MODID)
public class ModContent {
    public static final Block METEOR_BLOCK = new BlockMeteor();
    public static final Item METEOR_SHARD = new Item().setRegistryName(JojoStands.MODID, "meteor_shard")
            .setTranslationKey("meteor_shard").setCreativeTab(CreativeTabs.MISC);
    public static final Item METEOR_ARROW = new ItemMeteorArrow();
    public static final Item METEOR_BLOCK_ITEM = new ItemBlock(METEOR_BLOCK).setRegistryName(METEOR_BLOCK.getRegistryName());

    @SubscribeEvent
    public static void registerBlocks(RegistryEvent.Register<Block> e) {
        e.getRegistry().register(METEOR_BLOCK);
    }

    @SubscribeEvent
    public static void registerItems(RegistryEvent.Register<Item> e) {
        e.getRegistry().registerAll(METEOR_SHARD, METEOR_ARROW, METEOR_BLOCK_ITEM);
    }
}
