package com.example.jojostands;

import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemBlock;
import net.minecraftforge.common.util.EnumHelper;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = JojoStands.MODID)
public class ModContent {
    public static final Block METEOR_BLOCK = new BlockMeteor();
    public static final Block DRIED_WOOD = new BlockSimple("dried_wood", Material.WOOD, 2.0F, SoundType.WOOD);
    public static final Block FRUIT_BLOCK = new BlockFruit();

    public static final Item METEOR_SHARD = new Item().setRegistryName(JojoStands.MODID, "meteor_shard")
            .setTranslationKey("meteor_shard").setCreativeTab(CreativeTabs.MISC);
    public static final Item METEOR_ARROW = new ItemMeteorArrow();
    public static final Item EISHA_STONE = new Item().setRegistryName(JojoStands.MODID, "eisha_stone")
            .setTranslationKey("eisha_stone").setCreativeTab(CreativeTabs.MISC);
    public static final Item SPECIAL_FRUIT = new ItemSpecialFruit();

    public static final ItemArmor.ArmorMaterial MASK_MAT = EnumHelper.addArmorMaterial(
            "JOJO_MASK", "jojostands:mask", 12, new int[]{1, 2, 3, 1}, 8, SoundEvents.ITEM_ARMOR_EQUIP_GENERIC, 0.0F);
    public static final ItemArmor.ArmorMaterial MASK_EISHA_MAT = EnumHelper.addArmorMaterial(
            "JOJO_MASK_EISHA", "jojostands:mask_eisha", 25, new int[]{2, 4, 5, 2}, 12, SoundEvents.ITEM_ARMOR_EQUIP_GENERIC, 1.0F);
    public static final Item STONE_MASK = new ItemMask(MASK_MAT, "stone_mask");
    public static final Item STONE_MASK_EISHA = new ItemMask(MASK_EISHA_MAT, "stone_mask_eisha");

    public static final Item.ToolMaterial ANUBIS_MAT = EnumHelper.addToolMaterial("JOJO_ANUBIS", 3, 0, 8.0F, 5.0F, 15);
    public static final Item ANUBIS_SWORD = new ItemAnubisSword(ANUBIS_MAT);

    public static final Item METEOR_BLOCK_ITEM = new ItemBlock(METEOR_BLOCK).setRegistryName(METEOR_BLOCK.getRegistryName());
    public static final Item DRIED_WOOD_ITEM = new ItemBlock(DRIED_WOOD).setRegistryName(DRIED_WOOD.getRegistryName());
    public static final Item FRUIT_BLOCK_ITEM = new ItemBlock(FRUIT_BLOCK).setRegistryName(FRUIT_BLOCK.getRegistryName());

    @SubscribeEvent
    public static void registerBlocks(RegistryEvent.Register<Block> e) {
        e.getRegistry().registerAll(METEOR_BLOCK, DRIED_WOOD, FRUIT_BLOCK);
    }

    @SubscribeEvent
    public static void registerItems(RegistryEvent.Register<Item> e) {
        e.getRegistry().registerAll(METEOR_SHARD, METEOR_ARROW, EISHA_STONE, SPECIAL_FRUIT,
                STONE_MASK, STONE_MASK_EISHA, ANUBIS_SWORD, METEOR_BLOCK_ITEM, DRIED_WOOD_ITEM, FRUIT_BLOCK_ITEM);
    }
}
