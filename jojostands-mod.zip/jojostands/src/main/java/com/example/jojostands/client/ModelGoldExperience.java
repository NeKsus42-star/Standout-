package com.example.jojostands.client;

import com.example.jojostands.entity.EntityStandHand;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;

/**
 * Gold Experience: тонкая золотая фигура с суставами (локти, колени), фиолетовые вставки,
 * белые шипы на плечах и ремни на бёдрах. Размер как у игрока (32 пикселя в высоту).
 * Поза ожидания: левая рука на бедре, правая нога поднята и согнута.
 */
public class ModelGoldExperience extends ModelBase {
    private final ModelRenderer chest, abdomen, pelvis, head;
    private final ModelRenderer rUpper, rFore, lUpper, lFore;
    private final ModelRenderer rThigh, rShin, rFoot, lThigh, lShin, lFoot;

    private ModelRenderer box(int[] uv, float x, float y, float z, int w, int h, int d) {
        ModelRenderer r = new ModelRenderer(this, uv[0], uv[1]);
        r.addBox(x, y, z, w, h, d);
        return r;
    }

    public ModelGoldExperience() {
        textureWidth = 128;
        textureHeight = 128;
        // торс
        chest = box(new int[]{52, 0}, -4, 0, -2, 8, 6, 4);
        chest.setRotationPoint(0, 0, 0);
        head = box(new int[]{0, 0}, -4, -8, -4, 8, 8, 8);
        head.setRotationPoint(0, 0, 0);
        chest.addChild(head);
        ModelRenderer crest = box(new int[]{32, 0}, -1, -10, -4, 2, 2, 8);
        head.addChild(crest);
        abdomen = box(new int[]{88, 0}, -3, 0, -1.5F, 6, 5, 3);
        abdomen.setRotationPoint(0, 6, 0);
        chest.addChild(abdomen);
        pelvis = box(new int[]{40, 16}, -3.5F, 0, -2, 7, 2, 4);
        pelvis.setRotationPoint(0, 11, 0);

        // фиолетовые вставки на груди
        ModelRenderer s1 = box(new int[]{94, 16}, -3, 2, -2.5F, 2, 2, 1);
        ModelRenderer s2 = box(new int[]{94, 16}, 1, 2, -2.5F, 2, 2, 1);
        chest.addChild(s1);
        chest.addChild(s2);

        // белые шипы на плечах
        ModelRenderer spR = box(new int[]{66, 16}, -1.5F, -4, -0.5F, 3, 4, 1);
        spR.setRotationPoint(-4.5F, 0.5F, 0);
        spR.rotateAngleZ = -0.5F;
        ModelRenderer spL = box(new int[]{66, 16}, -1.5F, -4, -0.5F, 3, 4, 1);
        spL.setRotationPoint(4.5F, 0.5F, 0);
        spL.rotateAngleZ = 0.5F;
        chest.addChild(spR);
        chest.addChild(spL);

        // ремни на бёдрах
        ModelRenderer stR = box(new int[]{62, 16}, -0.5F, 0, -0.5F, 1, 5, 1);
        stR.setRotationPoint(-3.8F, 1, -1.5F);
        stR.rotateAngleZ = 0.5F;
        ModelRenderer stL = box(new int[]{62, 16}, -0.5F, 0, -0.5F, 1, 5, 1);
        stL.setRotationPoint(3.8F, 1, -1.5F);
        stL.rotateAngleZ = -0.5F;
        pelvis.addChild(stR);
        pelvis.addChild(stL);

        // руки: плечо - предплечье - кисть
        rUpper = box(new int[]{106, 0}, -1.5F, -1.5F, -1.5F, 3, 5, 3);
        rUpper.setRotationPoint(-5.5F, 1.5F, 0);
        rFore = box(new int[]{0, 16}, -1.5F, 0, -1.5F, 3, 5, 3);
        rFore.setRotationPoint(0, 3.5F, 0);
        ModelRenderer rHand = box(new int[]{74, 16}, -1.5F, 0, -1.5F, 3, 2, 3);
        rHand.setRotationPoint(0, 5, 0);
        ModelRenderer rStud = box(new int[]{94, 16}, -1, 0, -2, 2, 2, 1);
        rHand.addChild(rStud);
        rUpper.addChild(rFore);
        rFore.addChild(rHand);
        chest.addChild(rUpper);

        lUpper = box(new int[]{106, 0}, -1.5F, -1.5F, -1.5F, 3, 5, 3);
        lUpper.setRotationPoint(5.5F, 1.5F, 0);
        lFore = box(new int[]{0, 16}, -1.5F, 0, -1.5F, 3, 5, 3);
        lFore.setRotationPoint(0, 3.5F, 0);
        ModelRenderer lHand = box(new int[]{74, 16}, -1.5F, 0, -1.5F, 3, 2, 3);
        lHand.setRotationPoint(0, 5, 0);
        ModelRenderer lStud = box(new int[]{94, 16}, -1, 0, -2, 2, 2, 1);
        lHand.addChild(lStud);
        lUpper.addChild(lFore);
        lFore.addChild(lHand);
        chest.addChild(lUpper);

        // ноги: бедро - голень - ботинок, фиолетовые наколенники
        rThigh = box(new int[]{76, 0}, -1.5F, 0, -1.5F, 3, 6, 3);
        rThigh.setRotationPoint(-2, 11, 0);
        rShin = box(new int[]{12, 16}, -1.5F, 0, -1.5F, 3, 5, 3);
        rShin.setRotationPoint(0, 6, 0);
        rFoot = box(new int[]{24, 16}, -1.5F, 0, -3.5F, 3, 2, 5);
        rFoot.setRotationPoint(0, 5, 0);
        ModelRenderer rKnee = box(new int[]{86, 16}, -1.5F, 4.5F, -2.5F, 3, 3, 1);
        rThigh.addChild(rKnee);
        rThigh.addChild(rShin);
        rShin.addChild(rFoot);

        lThigh = box(new int[]{76, 0}, -1.5F, 0, -1.5F, 3, 6, 3);
        lThigh.setRotationPoint(2, 11, 0);
        lShin = box(new int[]{12, 16}, -1.5F, 0, -1.5F, 3, 5, 3);
        lShin.setRotationPoint(0, 6, 0);
        lFoot = box(new int[]{24, 16}, -1.5F, 0, -3.5F, 3, 2, 5);
        lFoot.setRotationPoint(0, 5, 0);
        ModelRenderer lKnee = box(new int[]{86, 16}, -1.5F, 4.5F, -2.5F, 3, 3, 1);
        lThigh.addChild(lKnee);
        lThigh.addChild(lShin);
        lShin.addChild(lFoot);
    }

    private static void zero(ModelRenderer... parts) {
        for (ModelRenderer p : parts) {
            p.rotateAngleX = 0.0F;
            p.rotateAngleY = 0.0F;
            p.rotateAngleZ = 0.0F;
        }
    }

    @Override
    public void render(Entity entity, float a, float b, float ageInTicks, float d, float f, float scale) {
        setRotationAngles(a, b, ageInTicks, d, f, scale, entity);
        chest.render(scale);
        pelvis.render(scale);
        rThigh.render(scale);
        lThigh.render(scale);
    }

    @Override
    public void setRotationAngles(float a, float b, float ageInTicks, float d, float f, float scale, Entity entity) {
        zero(chest, abdomen, pelvis, head, rUpper, rFore, lUpper, lFore, rThigh, rShin, rFoot, lThigh, lShin, lFoot);
        if (!(entity instanceof EntityStandHand)) return;
        EntityStandHand e = (EntityStandHand) entity;
        float t = ageInTicks;

        if (e.getAttackTicks() > 0) {
            // серия быстрых ударов: руки по очереди выпрямляются вперёд
            float ext = (MathHelper.sin(t * 1.9F) + 1.0F) / 2.0F;
            chest.rotateAngleX = 0.25F;
            chest.rotateAngleY = (ext - 0.5F) * 0.3F;
            head.rotateAngleX = -0.15F;
            rUpper.rotateAngleX = -1.4F;
            lUpper.rotateAngleX = -1.4F;
            rFore.rotateAngleX = -(1.0F - ext) * 1.3F;
            lFore.rotateAngleX = -ext * 1.3F;
            lThigh.rotateAngleX = 0.35F;
            rThigh.rotateAngleX = -0.35F;
            rShin.rotateAngleX = 0.4F;
        } else if (e.isReach()) {
            float sway = MathHelper.sin(t * 0.3F) * 0.05F;
            rUpper.rotateAngleX = -1.5F;
            lUpper.rotateAngleX = -1.5F;
            rFore.rotateAngleX = -0.1F + sway;
            lFore.rotateAngleX = -0.1F - sway;
            chest.rotateAngleX = 0.15F;
        } else {
            // поза с рисунка
            float sway = MathHelper.sin(t * 0.08F) * 0.03F;
            head.rotateAngleZ = 0.12F + sway;
            head.rotateAngleX = 0.12F;
            head.rotateAngleY = -0.15F;
            chest.rotateAngleZ = -0.06F;
            chest.rotateAngleY = 0.12F;
            abdomen.rotateAngleZ = 0.1F;
            abdomen.rotateAngleY = -0.1F;
            // левая рука на бедре
            lUpper.rotateAngleZ = -0.85F;
            lUpper.rotateAngleX = 0.15F;
            lFore.rotateAngleZ = 1.7F;
            lFore.rotateAngleX = -0.2F;
            // правая рука свисает к колену
            rUpper.rotateAngleZ = 0.25F;
            rUpper.rotateAngleX = -0.1F;
            rFore.rotateAngleZ = 0.15F;
            rFore.rotateAngleX = -0.35F;
            // левая нога стоит, правая поднята и согнута
            lThigh.rotateAngleZ = -0.06F;
            rThigh.rotateAngleX = -0.85F;
            rThigh.rotateAngleZ = -0.25F;
            rShin.rotateAngleX = 1.35F;
            rFoot.rotateAngleX = 0.4F;
        }
    }
}
