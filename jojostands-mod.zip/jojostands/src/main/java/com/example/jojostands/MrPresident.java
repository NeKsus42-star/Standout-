package com.example.jojostands;

import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;

/** Mr. President: единственная способность - карманное измерение. Работает только с ключом в руке. */
public class MrPresident {
    public static void toggle(EntityPlayerMP p) {
        ItemStack held = p.getHeldItemMainhand();
        if (held.getItem() != ModContent.KEY) {
            StandLogic.msg(p, "Возьмите ключ в руку");
            return;
        }
        if (StandLogic.cooldown(p, "pocket", 40)) return;
        if (p.world.provider.getDimension() == PocketDimension.DIM_ID) PocketDimension.leave(p);
        else PocketDimension.enter(p);
    }
}
