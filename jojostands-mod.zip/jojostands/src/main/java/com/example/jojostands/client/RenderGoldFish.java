package com.example.jojostands.client;

import com.example.jojostands.JojoStands;
import com.example.jojostands.entity.EntityGoldFish;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;

public class RenderGoldFish extends Render<EntityGoldFish> {
    private static final ResourceLocation TEX = new ResourceLocation(JojoStands.MODID, "textures/entity/goldfish.png");

    private static class ModelFish extends ModelBase {
        private final ModelRenderer body, tail;

        ModelFish() {
            textureWidth = 32;
            textureHeight = 32;
            body = new ModelRenderer(this, 0, 0);
            body.addBox(-1.5F, -2F, -4F, 3, 4, 8);
            tail = new ModelRenderer(this, 0, 14);
            tail.addBox(-0.5F, -3F, 4F, 1, 6, 3);
        }

        @Override
        public void render(Entity e, float a, float b, float c, float d, float f, float scale) {
            body.render(scale);
            tail.render(scale);
        }
    }

    private final ModelFish model = new ModelFish();

    public RenderGoldFish(RenderManager m) {
        super(m);
    }

    @Override
    public void doRender(EntityGoldFish e, double x, double y, double z, float yaw, float pt) {
        GlStateManager.pushMatrix();
        GlStateManager.translate(x, y + 0.2, z);
        float ry = e.prevRotationYaw + MathHelper.wrapDegrees(e.rotationYaw - e.prevRotationYaw) * pt;
        GlStateManager.rotate(180.0F - ry, 0.0F, 1.0F, 0.0F);
        GlStateManager.enableRescaleNormal();
        GlStateManager.scale(-1.0F, -1.0F, 1.0F);
        bindEntityTexture(e);
        model.render(e, 0, 0, 0, 0, 0, 0.0625F * 1.5F);
        GlStateManager.disableRescaleNormal();
        GlStateManager.popMatrix();
        super.doRender(e, x, y, z, yaw, pt);
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityGoldFish e) {
        return TEX;
    }
}
