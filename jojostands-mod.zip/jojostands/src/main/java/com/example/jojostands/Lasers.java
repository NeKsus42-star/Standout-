package com.example.jojostands;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

/** Лазеры из глаз: мгновенно убивают живых, блоки ломают постепенно. */
public class Lasers {
    public static final int DURATION = 100;   // 5 секунд
    public static final int COOLDOWN = 600;   // 30 секунд
    public static final double RANGE = 40.0;

    private static class L {
        int ticks = DURATION;
        int dim;
        Map<BlockPos, Integer> progress = new HashMap<>();
    }

    private static final Map<UUID, L> ACTIVE = new HashMap<>();

    public static void start(EntityPlayerMP p) {
        if (ACTIVE.containsKey(p.getUniqueID())) return;
        if (StandLogic.cooldown(p, "laser", COOLDOWN)) return;
        L l = new L();
        l.dim = p.world.provider.getDimension();
        ACTIVE.put(p.getUniqueID(), l);
        StandLogic.msg(p, "Лазеры из глаз!");
    }

    public static void tick(World w) {
        if (ACTIVE.isEmpty() || !(w instanceof WorldServer)) return;
        WorldServer ws = (WorldServer) w;
        int dim = w.provider.getDimension();
        for (Map.Entry<UUID, L> en : new ArrayList<>(ACTIVE.entrySet())) {
            L l = en.getValue();
            if (l.dim != dim) continue;
            EntityPlayer p = w.getPlayerEntityByUUID(en.getKey());
            if (p == null || p.isDead || --l.ticks <= 0) {
                ACTIVE.remove(en.getKey());
                continue;
            }
            Vec3d eye = p.getPositionEyes(1.0F);
            Vec3d look = p.getLookVec();
            RayTraceResult r = StandUtil.trace(p, RANGE, e -> e instanceof EntityLivingBase);
            double len = r != null ? r.hitVec.distanceTo(eye) : RANGE;

            for (double d = 0.6; d < len; d += 0.7) {
                ws.spawnParticle(EnumParticleTypes.REDSTONE, eye.x + look.x * d, eye.y - 0.1 + look.y * d, eye.z + look.z * d, 1, 0, 0, 0, 0.0);
            }
            if (r == null) continue;

            if (r.entityHit != null) {
                Entity t = r.entityHit;
                if (t instanceof EntityLivingBase) {
                    ((EntityLivingBase) t).hurtResistantTime = 0;
                    t.attackEntityFrom(DamageSource.causePlayerDamage(p), 1000.0F);
                }
            } else {
                BlockPos pos = r.getBlockPos();
                IBlockState st = w.getBlockState(pos);
                float h = st.getBlockHardness(w, pos);
                if (h < 0) continue; // бедрок и т.п.
                int need = Math.max(5, (int) (h * 8));
                int prog = l.progress.containsKey(pos) ? l.progress.get(pos) + 1 : 1;
                l.progress.put(pos, prog);
                w.sendBlockBreakProgress(p.getEntityId(), pos, Math.min(9, prog * 10 / need));
                if (prog >= need) {
                    w.destroyBlock(pos, true);
                    w.sendBlockBreakProgress(p.getEntityId(), pos, -1);
                    l.progress.remove(pos);
                }
            }
        }
    }
}
