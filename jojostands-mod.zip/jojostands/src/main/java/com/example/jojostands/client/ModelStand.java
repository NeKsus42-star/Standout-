package com.example.jojostands.client;

import com.example.jojostands.StandData;
import com.example.jojostands.entity.EntityStandHand;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;

/** Модель стенда: фигура игрока с анимациями ударов, позой ожидания и дополнительными деталями. */
public class ModelStand extends ModelPlayer {
    private final ModelRenderer earsKQ;
    private final ModelRenderer earsAnubis;

    public ModelStand() {
        super(0.0F, false);
        // второй слой одежды не нужен: эти области текстуры используются под уши
        bipedBodyWear.showModel = false;
        bipedLeftArmwear.showModel = false;
        bipedRightArmwear.showModel = false;
        bipedLeftLegwear.showModel = false;
        bipedRightLegwear.showModel = false;

        earsKQ = new ModelRenderer(this, 0, 32);
        earsKQ.addBox(-4.0F, -11.0F, -1.0F, 2, 3, 2);
        earsKQ.addBox(2.0F, -11.0F, -1.0F, 2, 3, 2);
        bipedHead.addChild(earsKQ);

        earsAnubis = new ModelRenderer(this, 0, 40);
        earsAnubis.addBox(-3.5F, -13.0F, 0.0F, 2, 5, 1);
        earsAnubis.addBox(1.5F, -13.0F, 0.0F, 2, 5, 1);
        bipedHead.addChild(earsAnubis);
    }

    @Override
    public void setRotationAngles(float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw,
                                  float headPitch, float scaleFactor, Entity entityIn) {
        super.setRotationAngles(0.0F, 0.0F, ageInTicks, 0.0F, 0.0F, scaleFactor, entityIn);
        if (!(entityIn instanceof EntityStandHand)) return;
        EntityStandHand e = (EntityStandHand) entityIn;
        int type = e.getStandType();
        float t = ageInTicks;

        earsKQ.showModel = type == StandData.KILLER_QUEEN;
        earsAnubis.showModel = type == StandData.ANUBIS;

        if (e.getAttackTicks() > 0) {
            switch (type) {
                case StandData.KILLER_QUEEN: { // тяжёлые одиночные удары с поворотом корпуса
                    float p = (MathHelper.sin(t * 0.9F) + 1.0F) / 2.0F;
                    bipedRightArm.rotateAngleX = -0.4F - 1.4F * p;
                    bipedLeftArm.rotateAngleX = -1.0F + 0.3F * p;
                    bipedBody.rotateAngleY = (p - 0.5F) * 0.5F;
                    bipedRightArm.rotateAngleY = -0.2F;
                    break;
                }
                case StandData.ANUBIS: { // рубящие удары сверху вниз
                    float p = (t * 0.45F) % 1.0F;
                    bipedRightArm.rotateAngleX = -3.0F + p * 2.6F;
                    bipedLeftArm.rotateAngleX = -0.4F;
                    bipedBody.rotateAngleY = (p - 0.5F) * 0.6F;
                    break;
                }
                default: { // серия быстрых ударов обеими руками
                    float f = type == StandData.STAR_PLATINUM ? 2.4F : type == StandData.GOLD_EXPERIENCE ? 1.9F : 1.5F;
                    float s = MathHelper.sin(t * f) * 0.55F;
                    bipedRightArm.rotateAngleX = -1.5F + s;
                    bipedLeftArm.rotateAngleX = -1.5F - s;
                    bipedRightArm.rotateAngleZ = 0.12F;
                    bipedLeftArm.rotateAngleZ = -0.12F;
                    bipedBody.rotateAngleX = 0.3F;
                    if (type == StandData.STICKY_FINGERS) bipedBody.rotateAngleZ = MathHelper.sin(t * f * 0.5F) * 0.15F;
                    if (type == StandData.GOLD_EXPERIENCE) bipedHead.rotateAngleZ = 0.2F;
                }
            }
            bipedRightLeg.rotateAngleX = 0.5F;
            bipedLeftLeg.rotateAngleX = -0.5F;
        } else if (e.isReach()) { // тянется за предметом
            float sway = MathHelper.sin(t * 0.3F) * 0.1F;
            bipedRightArm.rotateAngleX = -1.5F + sway;
            bipedLeftArm.rotateAngleX = -1.5F - sway;
        } else {
            switch (type) { // позы ожидания
                case StandData.KILLER_QUEEN:
                    bipedRightArm.rotateAngleX = 0.2F;
                    bipedLeftArm.rotateAngleX = 0.2F;
                    bipedRightArm.rotateAngleZ = 0.1F;
                    bipedLeftArm.rotateAngleZ = -0.1F;
                    break;
                case StandData.STAR_PLATINUM:
                    bipedRightArm.rotateAngleX = -0.6F;
                    bipedLeftArm.rotateAngleX = -0.6F;
                    bipedRightArm.rotateAngleY = -0.3F;
                    bipedLeftArm.rotateAngleY = 0.3F;
                    break;
                case StandData.GOLD_EXPERIENCE:
                    bipedRightArm.rotateAngleX = -0.35F;
                    bipedLeftArm.rotateAngleX = 0.25F;
                    bipedHead.rotateAngleZ = 0.1F;
                    break;
                case StandData.STICKY_FINGERS:
                    bipedRightArm.rotateAngleX = -0.2F;
                    bipedLeftArm.rotateAngleX = 0.1F;
                    break;
                case StandData.ANUBIS:
                    bipedRightArm.rotateAngleX = -1.0F;
                    bipedLeftArm.rotateAngleX = 0.2F;
                    break;
                default:
            }
        }
        copyModelAngles(bipedHead, bipedHeadwear);
    }
}
