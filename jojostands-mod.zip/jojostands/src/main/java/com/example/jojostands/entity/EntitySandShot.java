package com.example.jojostands.entity;

import java.util.UUID;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

/** Блок песка Anubis: летит вперёд и быстро вращается вокруг оси полёта. 3 сердца за попадание. */
public class EntitySandShot extends EntityLerp {
    private UUID ownerId;
    private Vec3d start, dir, u, v;
    private float phase;
    private int age;

    public EntitySandShot(World w) {
        super(w);
        setSize(0.5F, 0.5F);
        noClip = true;
        lerpSteps = 1;
        ignoreFrustumCheck = true;
    }

    public EntitySandShot(World w, EntityPlayer owner, Vec3d start, Vec3d dir, float phase) {
        this(w);
        this.ownerId = owner.getUniqueID();
        this.start = start;
        this.dir = dir.normalize();
        this.phase = phase;
        Vec3d up = Math.abs(this.dir.y) > 0.95 ? new Vec3d(1, 0, 0) : new Vec3d(0, 1, 0);
        this.u = this.dir.crossProduct(up).normalize();
        this.v = this.dir.crossProduct(u).normalize();
        setPosition(start.x, start.y, start.z);
    }

    @Override
    public void onUpdate() {
        super.onUpdate();
        if (world.isRemote) {
            lerpClient();
            return;
        }
        if (ownerId == null || start == null || ++age > 40) {
            setDead();
            return;
        }
        double d = age * 1.1;
        double ang = phase + age * 0.8;
        double r = 0.9;
        double c = Math.cos(ang) * r, s = Math.sin(ang) * r;
        double x = start.x + dir.x * d + u.x * c + v.x * s;
        double y = start.y + dir.y * d + u.y * c + v.y * s;
        double z = start.z + dir.z * d + u.z * c + v.z * s;
        setPosition(x, y, z);

        if (world.getBlockState(new BlockPos(x, y, z)).getMaterial().blocksMovement()) {
            ((WorldServer) world).spawnParticle(EnumParticleTypes.BLOCK_CRACK, x, y, z, 8, 0.2, 0.2, 0.2, 0.05, net.minecraft.block.Block.getStateId(net.minecraft.init.Blocks.SAND.getDefaultState()));
            setDead();
            return;
        }
        EntityPlayer owner = world.getPlayerEntityByUUID(ownerId);
        for (EntityLivingBase e : world.getEntitiesWithinAABB(EntityLivingBase.class, getEntityBoundingBox().grow(0.4))) {
            if (e == owner) continue;
            e.hurtResistantTime = 0;
            e.attackEntityFrom(owner != null ? DamageSource.causePlayerDamage(owner) : DamageSource.GENERIC, 6.0F);
            setDead();
            return;
        }
    }
}
