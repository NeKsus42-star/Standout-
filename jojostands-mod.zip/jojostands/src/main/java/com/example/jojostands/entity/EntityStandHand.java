package com.example.jojostands.entity;

import com.example.jojostands.StandData;
import com.example.jojostands.StandUtil;
import java.util.UUID;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

/**
 * Стенд: полноценная фигура (модель игрока) рядом с владельцем. Ударяет серией ударов, тащит предметы.
 * Для Geb используется только как носитель воды (рисуется вода, а не фигура).
 */
public class EntityStandHand extends EntityLerp {
    private static final DataParameter<Integer> STAND = EntityDataManager.createKey(EntityStandHand.class, DataSerializers.VARINT);
    private static final DataParameter<Integer> CHARGES = EntityDataManager.createKey(EntityStandHand.class, DataSerializers.VARINT);
    private static final DataParameter<Boolean> FORM = EntityDataManager.createKey(EntityStandHand.class, DataSerializers.BOOLEAN);
    private static final DataParameter<Integer> ATK = EntityDataManager.createKey(EntityStandHand.class, DataSerializers.VARINT);
    private static final DataParameter<Boolean> REACH = EntityDataManager.createKey(EntityStandHand.class, DataSerializers.BOOLEAN);

    private static final float[] DMG = {0F, 7F, 10F, 6F, 7F, 0F, 8F, 0F};
    private static final double PUNCH_RANGE = 8.0;
    private static final double GRAB_RANGE = 48.0;
    private static final int IDLE = 0, GOTO = 1, ATTACK = 2, BACK = 3;

    private UUID ownerId;
    private int state = IDLE;
    private boolean punchMode;
    private Vec3d targetPos;
    private Entity targetEntity;
    private Entity carried;
    private int ticks;
    private int attackLeft;

    public EntityStandHand(World w) {
        super(w);
        setSize(0.6F, 1.8F);
        noClip = true;
        ignoreFrustumCheck = true;
    }

    public EntityStandHand(World w, EntityPlayer owner, int type) {
        this(w);
        ownerId = owner.getUniqueID();
        dataManager.set(STAND, type);
        Vec3d p = idlePos(owner);
        setPosition(p.x, p.y, p.z);
        rotationYaw = owner.rotationYaw;
        rotationPitch = 0.0F;
    }

    @Override
    protected void entityInit() {
        dataManager.register(STAND, 0);
        dataManager.register(CHARGES, 0);
        dataManager.register(FORM, false);
        dataManager.register(ATK, 0);
        dataManager.register(REACH, false);
    }

    public int getStandType() {
        return dataManager.get(STAND);
    }

    public int getCharges() {
        return dataManager.get(CHARGES);
    }

    public void setCharges(int n) {
        dataManager.set(CHARGES, Math.max(0, Math.min(com.example.jojostands.Geb.MAX, n)));
    }

    public boolean isForm() {
        return dataManager.get(FORM);
    }

    public void setForm(boolean b) {
        dataManager.set(FORM, b);
    }

    /** > 0 пока идёт серия ударов (для анимации). */
    public int getAttackTicks() {
        return dataManager.get(ATK);
    }

    /** true пока стенд тянется за предметом / несёт его. */
    public boolean isReach() {
        return dataManager.get(REACH);
    }

    /** Позиция (ноги) рядом с владельцем: сзади справа. */
    private static Vec3d idlePos(EntityPlayer o) {
        double yaw = Math.toRadians(o.rotationYaw);
        double fx = -Math.sin(yaw), fz = Math.cos(yaw);
        double rx = -Math.cos(yaw), rz = -Math.sin(yaw);
        return new Vec3d(o.posX + rx * 0.7 - fx * 0.9, o.posY + 0.15, o.posZ + rz * 0.7 - fz * 0.9);
    }

    /** Где встать, чтобы бить цель: перед ней со стороны владельца. */
    private static Vec3d standNear(EntityPlayer o, Entity t) {
        double dx = t.posX - o.posX, dz = t.posZ - o.posZ;
        double h = Math.sqrt(dx * dx + dz * dz);
        if (h < 1.0E-3) return new Vec3d(t.posX, t.posY, t.posZ);
        double back = h > 2.5 ? 1.4 : 0.6;
        return new Vec3d(t.posX - dx / h * back, t.posY, t.posZ - dz / h * back);
    }

    // ---------------- команды ----------------
    public void punch(EntityPlayer o) {
        if (state == GOTO || state == ATTACK) return;
        RayTraceResult r = StandUtil.trace(o, PUNCH_RANGE, e -> e instanceof EntityLivingBase);
        punchMode = true;
        targetEntity = null;
        if (r != null && r.entityHit != null) {
            targetEntity = r.entityHit;
            targetPos = standNear(o, targetEntity);
        } else if (r != null) {
            targetPos = r.hitVec;
        } else {
            Vec3d l = o.getLookVec();
            targetPos = new Vec3d(o.posX + l.x * 3, o.posY + 0.15, o.posZ + l.z * 3);
        }
        go();
    }

    public void grab(EntityPlayer o) {
        if (state == GOTO || state == ATTACK || carried != null) return;
        RayTraceResult r = StandUtil.trace(o, GRAB_RANGE, e -> e instanceof EntityItem);
        if (r == null || r.entityHit == null) {
            o.sendStatusMessage(new TextComponentString("Предмет не найден в прицеле"), true);
            return;
        }
        punchMode = false;
        targetEntity = r.entityHit;
        targetPos = new Vec3d(targetEntity.posX, targetEntity.posY, targetEntity.posZ);
        go();
    }

    /** Стенд идёт в точку и делает серию ударов в воздух (жест), без урона. */
    public void gesture(Vec3d pos) {
        if (state == GOTO || state == ATTACK) return;
        punchMode = true;
        targetEntity = null;
        targetPos = new Vec3d(pos.x, pos.y - 0.9, pos.z);
        go();
    }

    public void thrust(EntityPlayer o) {
        Vec3d l = o.getLookVec();
        gesture(new Vec3d(o.posX + l.x * 2.5, o.posY + 0.9, o.posZ + l.z * 2.5));
    }

    private void go() {
        state = GOTO;
        ticks = 0;
        dataManager.set(REACH, !punchMode);
    }

    // ---------------- логика ----------------
    @Override
    public void onUpdate() {
        super.onUpdate();
        if (world.isRemote) {
            lerpClient();
            return;
        }
        EntityPlayer owner = ownerId == null ? null : world.getPlayerEntityByUUID(ownerId);
        if (owner == null || owner.isDead || StandData.get(owner) != getStandType()) {
            setDead();
            return;
        }
        if (getStandType() == StandData.GEB) {
            gebTick(owner);
            return;
        }
        Vec3d idle = idlePos(owner);
        if (getDistanceSq(idle.x, idle.y, idle.z) > 2500.0) {
            setPosition(idle.x, idle.y, idle.z);
            state = IDLE;
            attackLeft = 0;
            dataManager.set(ATK, 0);
            release(owner);
            dataManager.set(REACH, false);
        }

        switch (state) {
            case GOTO: {
                Vec3d dest;
                if (targetEntity != null) {
                    if (targetEntity.isDead) {
                        toBack();
                        break;
                    }
                    dest = punchMode ? standNear(owner, targetEntity)
                            : new Vec3d(targetEntity.posX, targetEntity.posY, targetEntity.posZ);
                } else {
                    dest = targetPos;
                }
                Vec3d look = targetEntity != null ? StandUtil.center(targetEntity) : dest;
                face(look.x - posX, look.z - posZ);
                if (step(dest, 1.3)) arrive(owner);
                else if (++ticks > 80) toBack();
                break;
            }
            case ATTACK:
                attackTick(owner);
                break;
            case BACK:
                if (step(idle, 1.6)) {
                    state = IDLE;
                    release(owner);
                    dataManager.set(REACH, false);
                }
                break;
            default: {
                double d = Math.sqrt(getDistanceSq(idle.x, idle.y, idle.z));
                step(idle, Math.max(0.3, d * 0.4));
                rotationYaw = owner.rotationYaw;
                rotationPitch = 0.0F;
            }
        }

        if (!punchMode && (state == GOTO || state == BACK) && ticksExisted % 2 == 0) drawThread(owner);

        if (carried != null) {
            if (carried.isDead) {
                carried = null;
            } else {
                carried.setPosition(posX, posY + 1.0, posZ);
                carried.motionX = 0;
                carried.motionY = 0;
                carried.motionZ = 0;
                if (carried instanceof EntityItem) ((EntityItem) carried).setPickupDelay(20);
            }
        }
    }

    /** Geb: вода кружит вокруг владельца и пополняется из растений / источников воды. */
    private void gebTick(EntityPlayer owner) {
        setPosition(owner.posX, owner.posY, owner.posZ);
        rotationYaw = owner.rotationYaw;
        rotationPitch = 0.0F;
        if (ticksExisted % 8 == 0 && getCharges() < com.example.jojostands.Geb.MAX) {
            com.example.jojostands.Geb.absorb(this, owner);
        }
    }

    /** Нить из голубых частиц от игрока к стенду при захвате предметов. */
    private void drawThread(EntityPlayer o) {
        double fx = o.posX, fy = o.posY + o.getEyeHeight() - 0.3, fz = o.posZ;
        double dx = posX - fx, dy = posY + 1.0 - fy, dz = posZ - fz;
        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 0.5) return;
        int n = Math.max(1, (int) (len / 0.8));
        WorldServer ws = (WorldServer) world;
        for (int i = 0; i <= n; i++) {
            double t = (double) i / n;
            ws.spawnParticle(EnumParticleTypes.SPELL_MOB, fx + dx * t, fy + dy * t, fz + dz * t, 0, 0.2, 0.6, 1.0, 1.0);
        }
    }

    private void arrive(EntityPlayer owner) {
        if (punchMode) {
            state = ATTACK;
            attackLeft = targetEntity != null ? 16 : 8;
            dataManager.set(ATK, attackLeft);
        } else {
            if (targetEntity instanceof EntityItem && !targetEntity.isDead) {
                carried = targetEntity;
                carried.setNoGravity(true);
            }
            toBack();
        }
    }

    /** Серия ударов: 4 попадания за ~16 тиков, последнее с отбрасыванием. */
    private void attackTick(EntityPlayer owner) {
        attackLeft--;
        dataManager.set(ATK, Math.max(0, attackLeft));
        if (targetEntity != null && !targetEntity.isDead) {
            face(targetEntity.posX - posX, targetEntity.posZ - posZ);
            if (attackLeft >= 0 && attackLeft % 4 == 0) {
                targetEntity.hurtResistantTime = 0;
                targetEntity.attackEntityFrom(DamageSource.causePlayerDamage(owner), DMG[MathHelper.clamp(getStandType(), 0, 7)] / 4.0F);
                ((WorldServer) world).spawnParticle(EnumParticleTypes.CRIT, targetEntity.posX, targetEntity.posY + targetEntity.height / 2,
                        targetEntity.posZ, 8, 0.3, 0.3, 0.3, 0.3);
                world.playSound(null, posX, posY, posZ, SoundEvents.ENTITY_PLAYER_ATTACK_STRONG, SoundCategory.PLAYERS, 1.0F,
                        0.9F + world.rand.nextFloat() * 0.3F);
                if (attackLeft == 0 && targetEntity instanceof EntityLivingBase) {
                    ((EntityLivingBase) targetEntity).knockBack(owner, 1.2F, owner.posX - targetEntity.posX, owner.posZ - targetEntity.posZ);
                }
            }
        }
        if (attackLeft <= 0) toBack();
    }

    private void toBack() {
        state = BACK;
        attackLeft = 0;
        dataManager.set(ATK, 0);
        dataManager.set(REACH, carried != null);
    }

    /** Приносит предмет хозяину: кладём к его ногам, подбор сработает сам. */
    private void release(EntityPlayer owner) {
        if (carried != null && !carried.isDead) {
            carried.setNoGravity(false);
            carried.setPosition(owner.posX, owner.posY + 0.5, owner.posZ);
            if (carried instanceof EntityItem) ((EntityItem) carried).setPickupDelay(0);
        }
        carried = null;
    }

    @Override
    public void setDead() {
        if (!world.isRemote && carried != null && !carried.isDead) {
            carried.setNoGravity(false);
            if (carried instanceof EntityItem) ((EntityItem) carried).setPickupDelay(0);
            carried = null;
        }
        super.setDead();
    }

    private boolean step(Vec3d dest, double speed) {
        Vec3d diff = new Vec3d(dest.x - posX, dest.y - posY, dest.z - posZ);
        double dist = diff.length();
        if (dist <= speed) {
            setPosition(dest.x, dest.y, dest.z);
            return true;
        }
        setPosition(posX + diff.x / dist * speed, posY + diff.y / dist * speed, posZ + diff.z / dist * speed);
        return false;
    }

    /** Разворот корпуса стенда (только по горизонтали). */
    private void face(double dx, double dz) {
        if (dx * dx + dz * dz < 1.0E-4) return;
        rotationYaw = (float) (MathHelper.atan2(-dx, dz) * 180.0 / Math.PI);
        rotationPitch = 0.0F;
    }
}
