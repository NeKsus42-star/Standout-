package com.example.jojostands;

import java.io.File;
import net.minecraftforge.common.config.Configuration;

/** Шансы генерации. Файл: config/jojostands.cfg (меньше число = чаще). */
public class ModConfig {
    public static int METEOR_RARITY = 40;  // метеорит: 1 шанс из N на чанк
    public static int TREE_TRIES = 2;      // сколько попыток посадить дерево на чанк пустыни
    public static int TREE_RARITY = 3;     // дерево: 1 шанс из N на попытку
    public static int FRUIT_RARITY = 2;    // плод рокакаки на ветке: 1 шанс из N

    public static void load(File file) {
        Configuration c = new Configuration(file);
        METEOR_RARITY = c.getInt("meteorRarity", "worldgen", 40, 1, 100000, "Метеорит: 1 шанс из N на чанк (меньше - чаще)");
        TREE_TRIES = c.getInt("treeTries", "worldgen", 2, 0, 20, "Сколько попыток посадить засушенное дерево на чанк пустыни");
        TREE_RARITY = c.getInt("treeRarity", "worldgen", 3, 1, 1000, "Засушенное дерево: 1 шанс из N на попытку");
        FRUIT_RARITY = c.getInt("fruitRarity", "worldgen", 2, 1, 1000, "Плод рокакаки на ветке: 1 шанс из N");
        if (c.hasChanged()) c.save();
    }
}
