package com.example.jojostands.client;

import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;

/** Рисует текстурированный куб (текстура 16x16 на каждой грани) с простым затенением. */
public class CubeRender {
    public static void begin() {
        GlStateManager.disableLighting();
        GlStateManager.disableCull();
        GlStateManager.enableBlend();
        GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
        GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    }

    public static void end() {
        GlStateManager.disableBlend();
        GlStateManager.enableCull();
        GlStateManager.enableLighting();
    }

    /** h - половина ребра. */
    public static void draw(float h, float r, float g, float b, float a) {
        Tessellator t = Tessellator.getInstance();
        BufferBuilder bb = t.getBuffer();
        bb.begin(7, DefaultVertexFormats.POSITION_TEX_COLOR);
        quad(bb, -h, h, -h, h, h, -h, h, h, h, -h, h, h, r, g, b, a, 1.0F);
        quad(bb, -h, -h, h, h, -h, h, h, -h, -h, -h, -h, -h, r, g, b, a, 0.5F);
        quad(bb, h, -h, -h, -h, -h, -h, -h, h, -h, h, h, -h, r, g, b, a, 0.8F);
        quad(bb, -h, -h, h, h, -h, h, h, h, h, -h, h, h, r, g, b, a, 0.8F);
        quad(bb, -h, -h, -h, -h, -h, h, -h, h, h, -h, h, -h, r, g, b, a, 0.65F);
        quad(bb, h, -h, h, h, -h, -h, h, h, -h, h, h, h, r, g, b, a, 0.65F);
        t.draw();
    }

    private static void quad(BufferBuilder bb, float x1, float y1, float z1, float x2, float y2, float z2,
                             float x3, float y3, float z3, float x4, float y4, float z4,
                             float r, float g, float b, float a, float s) {
        bb.pos(x1, y1, z1).tex(0, 0).color(r * s, g * s, b * s, a).endVertex();
        bb.pos(x2, y2, z2).tex(1, 0).color(r * s, g * s, b * s, a).endVertex();
        bb.pos(x3, y3, z3).tex(1, 1).color(r * s, g * s, b * s, a).endVertex();
        bb.pos(x4, y4, z4).tex(0, 1).color(r * s, g * s, b * s, a).endVertex();
    }
}
