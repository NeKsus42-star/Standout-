package com.example.jojostands;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;
import net.minecraft.world.storage.MapStorage;
import net.minecraft.world.storage.WorldSavedData;

/** Камень Эйша выпадает только один раз за мир. */
public class EishaData extends WorldSavedData {
    public static final String ID = "jojostands_eisha";
    public boolean given;

    public EishaData() {
        super(ID);
    }

    public EishaData(String name) {
        super(name);
    }

    @Override
    public void readFromNBT(NBTTagCompound nbt) {
        given = nbt.getBoolean("given");
    }

    @Override
    public NBTTagCompound writeToNBT(NBTTagCompound nbt) {
        nbt.setBoolean("given", given);
        return nbt;
    }

    public static EishaData get(World w) {
        MapStorage s = w.getMapStorage();
        EishaData d = (EishaData) s.getOrLoadData(EishaData.class, ID);
        if (d == null) {
            d = new EishaData();
            s.setData(ID, d);
        }
        return d;
    }
}
