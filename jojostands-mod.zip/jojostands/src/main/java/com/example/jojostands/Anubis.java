package com.example.jojostands;

import com.example.jojostands.entity.EntitySandShot;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.passive.EntityTameable;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

/**
 * Anubis. Форма меча (по умолчанию): удар - волна-резак, способность - рубит всех мобов вокруг.
 * Кнопка захвата переключает меч <-> стенд. Форма стенда: обычный удар рукой, способность - 5 вращающихся блоков песка.
 */
public class Anubis {
    private static final String KEY = "anubisstand"; // true = форма стенда

    public static boolean standMode(EntityPlayer p) {
        NBTTagCompound d = p.getEntityData();
        return d.hasKey(EntityPlayer.PERSISTED_NBT_TAG, 10) && d.getCompoundTag(EntityPlayer.PERSISTED_NBT_TAG).getBoolean(KEY);
    }

    public static void setStandMode(EntityPlayer p, boolean v) {
        NBTTagCompound d = p.getEntityData();
        NBTTagCompound per = d.getCompoundTag(EntityPlayer.PERSISTED_NBT_TAG);
        per.setBoolean(KEY, v);
        d.setTag(EntityPlayer.PERSISTED_NBT_TAG, per);
    }

    public static void giveSword(EntityPlayer p) {
        ItemStack s = new ItemStack(ModContent.ANUBIS_SWORD);
        if (p.getHeldItemMainhand().isEmpty()) p.setHeldItem(EnumHand.MAIN_HAND, s);
        else if (!p.addItemStackToInventory(s)) p.dropItem(s, false);
    }

    public static void removeSword(EntityPlayer p) {
        for (int i = 0; i < p.inventory.getSizeInventory(); i++) {
            if (p.inventory.getStackInSlot(i).getItem() == ModContent.ANUBIS_SWORD) {
                p.inventory.setInventorySlotContents(i, ItemStack.EMPTY);
            }
        }
    }

    private static boolean holdingSword(EntityPlayerMP p) {
        if (p.getHeldItemMainhand().getItem() == ModContent.ANUBIS_SWORD) return true;
        StandLogic.msg(p, "Возьмите меч Анубиса в руку");
        return false;
    }

    // ---------------- волна-резак ----------------
    private static class Wave {
        Vec3d pos, dir, right;
        int ticks = 24, dim, blocks;
        UUID owner;
        Set<UUID> hit = new HashSet<>();
    }

    private static final List<Wave> WAVES = new ArrayList<>();

    public static void wave(EntityPlayerMP p) {
        if (!holdingSword(p)) return;
        if (StandLogic.cooldown(p, "awave", 15)) return;
        Vec3d look = p.getLookVec();
        double yr = Math.toRadians(p.rotationYaw);
        Wave w = new Wave();
        w.pos = p.getPositionEyes(1.0F).add(look.x, look.y, look.z);
        w.dir = look;
        w.right = new Vec3d(-Math.cos(yr), 0, -Math.sin(yr));
        w.dim = p.world.provider.getDimension();
        w.owner = p.getUniqueID();
        WAVES.add(w);
        p.world.playSound(null, p.posX, p.posY, p.posZ, SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, SoundCategory.PLAYERS, 1.0F, 0.8F);
    }

    // ---------------- ульта меча: все мобы в зоне 30x30 ----------------
    public static void ult(EntityPlayerMP p) {
        if (!holdingSword(p)) return;
        if (StandLogic.cooldown(p, "ault", 700)) return; // 35 секунд
        AxisAlignedBB box = new AxisAlignedBB(p.posX - 15, p.posY - 10, p.posZ - 15, p.posX + 15, p.posY + 10, p.posZ + 15);
        WorldServer ws = (WorldServer) p.world;
        for (EntityLiving e : p.world.getEntitiesWithinAABB(EntityLiving.class, box)) {
            if (!e.isEntityAlive()) continue;
            if (e instanceof EntityTameable && ((EntityTameable) e).isTamed()) continue;
            e.hurtResistantTime = 0;
            e.attackEntityFrom(DamageSource.causePlayerDamage(p), 10.0F); // 5 сердец
            ws.spawnParticle(EnumParticleTypes.SWEEP_ATTACK, e.posX, e.posY + e.height / 2, e.posZ, 1, 0, 0, 0, 0.0);
        }
        p.world.playSound(null, p.posX, p.posY, p.posZ, SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, SoundCategory.PLAYERS, 1.5F, 0.6F);
    }

    // ---------------- способность стенда: 5 вращающихся блоков песка ----------------
    public static void sand(EntityPlayerMP p) {
        if (StandLogic.cooldown(p, "asand", 60)) return;
        Vec3d look = p.getLookVec();
        Vec3d start = p.getPositionEyes(1.0F).add(look.x * 0.8, look.y * 0.8 - 0.2, look.z * 0.8);
        for (int i = 0; i < 5; i++) {
            p.world.spawnEntity(new EntitySandShot(p.world, p, start, look, (float) (i * 2 * Math.PI / 5)));
        }
        p.world.playSound(null, p.posX, p.posY, p.posZ, SoundEvents.BLOCK_SAND_BREAK, SoundCategory.PLAYERS, 1.2F, 0.7F);
    }

    public static void tick(World w) {
        if (WAVES.isEmpty() || !(w instanceof WorldServer)) return;
        WorldServer ws = (WorldServer) w;
        int dim = w.provider.getDimension();
        Iterator<Wave> it = WAVES.iterator();
        while (it.hasNext()) {
            Wave wv = it.next();
            if (wv.dim != dim) continue;
            if (--wv.ticks <= 0) {
                it.remove();
                continue;
            }
            wv.pos = wv.pos.add(wv.dir.x * 1.1, wv.dir.y * 1.1, wv.dir.z * 1.1);
            EntityPlayer owner = w.getPlayerEntityByUUID(wv.owner);

            for (int k = -2; k <= 2; k++) {
                ws.spawnParticle(EnumParticleTypes.CRIT, wv.pos.x + wv.right.x * k * 0.7, wv.pos.y, wv.pos.z + wv.right.z * k * 0.7, 1, 0, 0, 0, 0.0);
            }
            ws.spawnParticle(EnumParticleTypes.SWEEP_ATTACK, wv.pos.x, wv.pos.y, wv.pos.z, 1, 0, 0, 0, 0.0);

            AxisAlignedBB box = new AxisAlignedBB(wv.pos.x - 1.6, wv.pos.y - 1.2, wv.pos.z - 1.6, wv.pos.x + 1.6, wv.pos.y + 1.2, wv.pos.z + 1.6);
            for (EntityLivingBase e : w.getEntitiesWithinAABB(EntityLivingBase.class, box)) {
                if (e == owner || wv.hit.contains(e.getUniqueID())) continue;
                wv.hit.add(e.getUniqueID());
                e.attackEntityFrom(owner != null ? DamageSource.causePlayerDamage(owner) : DamageSource.GENERIC, 6.0F);
            }

            // немного рубит блоки: только мягкие, не больше 12 за волну
            boolean stop = false;
            for (int k = -1; k <= 1; k++) {
                for (int dy = -1; dy <= 1; dy++) {
                    BlockPos bp = new BlockPos(wv.pos.x + wv.right.x * k, wv.pos.y + dy, wv.pos.z + wv.right.z * k);
                    IBlockState st = w.getBlockState(bp);
                    if (st.getMaterial() == Material.AIR) continue;
                    float h = st.getBlockHardness(w, bp);
                    if (h >= 0 && h < 1.5F) {
                        if (wv.blocks < 12) {
                            w.destroyBlock(bp, true);
                            wv.blocks++;
                        }
                    } else if (k == 0 && dy == 0 && st.getMaterial().blocksMovement()) {
                        stop = true;
                    }
                }
            }
            if (stop) it.remove();
        }
    }
}
