package com.example.jojostands;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;

public class ItemMeteorArrow extends Item {
    public ItemMeteorArrow() {
        setRegistryName(JojoStands.MODID, "meteor_arrow");
        setUnlocalizedName("meteor_arrow");
        setCreativeTab(CreativeTabs.COMBAT);
    }

    @Override
    public ActionResult<ItemStack> onItemRightClick(World world, EntityPlayer player, EnumHand hand) {
        ItemStack stack = player.getHeldItem(hand);
        if (!world.isRemote) {
            if (StandData.get(player) != 0) {
                player.sendStatusMessage(new TextComponentString("У вас уже есть стенд"), true);
            } else {
                StandData.grantRandom(player);
                if (!player.capabilities.isCreativeMode) stack.shrink(1);
            }
        }
        return new ActionResult<>(EnumActionResult.SUCCESS, stack);
    }
}
