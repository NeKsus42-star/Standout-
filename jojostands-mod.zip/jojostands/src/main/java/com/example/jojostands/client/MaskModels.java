package com.example.jojostands.client;

import net.minecraft.client.model.ModelBiped;

public class MaskModels {
    private static ModelStoneMask model;

    public static ModelBiped get() {
        if (model == null) model = new ModelStoneMask();
        return model;
    }
}
