package com.example.jojostands;

import com.example.jojostands.client.RenderGoldFish;
import com.example.jojostands.client.RenderSandShot;
import com.example.jojostands.client.RenderStandHand;
import com.example.jojostands.client.RenderWaterShot;
import com.example.jojostands.entity.EntityGoldFish;
import com.example.jojostands.entity.EntityGoldShot;
import com.example.jojostands.entity.EntitySandShot;
import com.example.jojostands.entity.EntityStandHand;
import com.example.jojostands.entity.EntityWaterShot;
import com.example.jojostands.net.ModNetwork;
import com.example.jojostands.net.PacketAction;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.RenderSnowball;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.init.Items;
import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import org.lwjgl.input.Keyboard;

public class ClientProxy extends CommonProxy {
    private static final String CAT = "key.categories.jojostands";
    // R назначена сразу, остальные кнопки пустые - назначаются в настройках управления
    public static final KeyBinding KEY_SUMMON = new KeyBinding("key.jojostands.summon", Keyboard.KEY_R, CAT);
    public static final KeyBinding KEY_PUNCH = new KeyBinding("key.jojostands.punch", Keyboard.KEY_NONE, CAT);
    public static final KeyBinding KEY_ABILITY = new KeyBinding("key.jojostands.ability", Keyboard.KEY_NONE, CAT);
    public static final KeyBinding KEY_GRAB = new KeyBinding("key.jojostands.grab", Keyboard.KEY_NONE, CAT);

    @Override
    public void preInit() {
        ClientRegistry.registerKeyBinding(KEY_SUMMON);
        ClientRegistry.registerKeyBinding(KEY_PUNCH);
        ClientRegistry.registerKeyBinding(KEY_ABILITY);
        ClientRegistry.registerKeyBinding(KEY_GRAB);
        RenderingRegistry.registerEntityRenderingHandler(EntityStandHand.class, RenderStandHand::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityGoldFish.class, RenderGoldFish::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityWaterShot.class, RenderWaterShot::new);
        RenderingRegistry.registerEntityRenderingHandler(EntitySandShot.class, RenderSandShot::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityGoldShot.class,
                m -> new RenderSnowball<EntityGoldShot>(m, Items.GOLD_NUGGET, Minecraft.getMinecraft().getRenderItem()));
        MinecraftForge.EVENT_BUS.register(this);
    }

    @Override
    public void setClientStand(int stand) {
        Minecraft.getMinecraft().addScheduledTask(() -> {
            ClientState.stand = stand;
        });
    }

    @SubscribeEvent
    public void onKey(InputEvent.KeyInputEvent e) {
        poll();
    }

    @SubscribeEvent
    public void onMouse(InputEvent.MouseInputEvent e) {
        poll();
    }

    private void poll() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.player == null) return;
        if (KEY_SUMMON.isPressed()) send(mc, 0);
        if (KEY_PUNCH.isPressed()) send(mc, 1);
        if (KEY_ABILITY.isPressed()) send(mc, 2);
        if (KEY_GRAB.isPressed()) send(mc, 3);
    }

    private void send(Minecraft mc, int action) {
        ModNetwork.CHANNEL.sendToServer(new PacketAction(action));
    }
}
