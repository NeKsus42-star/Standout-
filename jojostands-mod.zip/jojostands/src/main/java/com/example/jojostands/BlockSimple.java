package com.example.jojostands;

import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;

public class BlockSimple extends Block {
    public BlockSimple(String name, Material mat, float hardness, SoundType sound) {
        super(mat);
        setRegistryName(JojoStands.MODID, name);
        setTranslationKey(name);
        setHardness(hardness);
        setResistance(hardness * 3.0F);
        setSoundType(sound);
        setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
    }
}
