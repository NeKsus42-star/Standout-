package com.example.jojostands;

import com.example.jojostands.entity.EntityStandHand;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.text.TextComponentString;

public class StandLogic {
    private static final Map<UUID, EntityStandHand> HANDS = new HashMap<>();
    private static final Map<String, Long> CDS = new HashMap<>();

    public static void msg(EntityPlayer p, String text) {
        p.sendStatusMessage(new TextComponentString(text), true);
    }

    /** true = ещё перезаряжается (и сообщение игроку); иначе запускает перезарядку. */
    public static boolean cooldown(EntityPlayerMP p, String tag, int ticks) {
        long now = p.world.getTotalWorldTime();
        String key = p.getUniqueID() + tag;
        Long until = CDS.get(key);
        if (until != null && now < until) {
            msg(p, "Перезарядка: " + ((until - now) / 20 + 1) + " c");
            return true;
        }
        CDS.put(key, now + ticks);
        return false;
    }

    private static void toggleAnubis(EntityPlayerMP p) {
        UUID id = p.getUniqueID();
        if (!Anubis.standMode(p)) {
            Anubis.removeSword(p);
            Anubis.setStandMode(p, true);
            EntityStandHand h = HANDS.get(id);
            if (h == null || h.isDead) {
                h = new EntityStandHand(p.world, p, StandData.ANUBIS);
                p.world.spawnEntity(h);
                HANDS.put(id, h);
            }
            msg(p, "Анубис: форма стенда");
        } else {
            EntityStandHand h = HANDS.remove(id);
            if (h != null) h.setDead();
            Anubis.setStandMode(p, false);
            Anubis.giveSword(p);
            msg(p, "Анубис: форма меча");
        }
    }

    public static void handle(EntityPlayerMP p, int action) {
        // в маске вампира клавиши удара/захвата/способности работают как способности вампира
        if (action != 0 && Vampire.active(p)) {
            Vampire.handle(p, action);
            return;
        }
        int type = StandData.get(p);
        if (type == 0) {
            msg(p, "У вас нет стенда");
            return;
        }

        // Anubis в форме меча: рука не нужна
        if (type == StandData.ANUBIS && !Anubis.standMode(p)) {
            if (action == 0) msg(p, "Анубис в форме меча. Кнопка захвата переключает на стенд");
            else if (action == 1) Anubis.wave(p);
            else if (action == 2) Anubis.ult(p);
            else if (action == 3) toggleAnubis(p);
            return;
        }

        // Mr. President: только способность (карманное измерение, нужен ключ в руке)
        if (type == StandData.MR_PRESIDENT && action != 0) {
            if (action == 2) MrPresident.toggle(p);
            else msg(p, "У Mr. President только способность (ключ в руке)");
            return;
        }

        UUID id = p.getUniqueID();
        EntityStandHand hand = HANDS.get(id);
        if (hand != null && (hand.isDead || hand.world != p.world)) {
            HANDS.remove(id);
            hand = null;
        }

        if (action == 0) {
            if (hand != null) {
                hand.setDead();
                HANDS.remove(id);
            } else {
                hand = new EntityStandHand(p.world, p, type);
                p.world.spawnEntity(hand);
                HANDS.put(id, hand);
            }
            return;
        }
        if (hand == null) {
            msg(p, "Сначала вызовите стенд");
            return;
        }
        switch (action) {
            case 1:
                if (type == StandData.GEB) Geb.shoot(p, hand);
                else hand.punch(p);
                break;
            case 2:
                if (type == StandData.KILLER_QUEEN) KillerQueen.ability(p, hand);
                else if (type == StandData.STAR_PLATINUM) TimeStop.toggle(p);
                else if (type == StandData.GOLD_EXPERIENCE) GoldExperience.shoot(p, hand);
                else if (type == StandData.STICKY_FINGERS) StickyFingers.ability(p);
                else if (type == StandData.GEB) Geb.ult(p, hand);
                else if (type == StandData.ANUBIS) Anubis.sand(p);
                break;
            case 3:
                if (type == StandData.GEB) Geb.dome(p, hand);
                else if (type == StandData.ANUBIS) toggleAnubis(p);
                else hand.grab(p);
                break;
            default:
        }
    }
}
