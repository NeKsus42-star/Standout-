package com.example.jojostands;

import com.example.jojostands.entity.EntityStandHand;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.text.TextComponentString;

public class StandLogic {
    private static final Map<UUID, EntityStandHand> HANDS = new HashMap<>();
    private static final Map<String, Long> CDS = new HashMap<>();

    public static void msg(EntityPlayer p, String text) {
        p.sendStatusMessage(new TextComponentString(text), true);
    }

    /** true = ещё перезаряжается (и сообщение игроку); иначе запускает перезарядку. */
    public static boolean cooldown(EntityPlayerMP p, String tag, int ticks) {
        long now = p.world.getTotalWorldTime();
        String key = p.getUniqueID() + tag;
        Long until = CDS.get(key);
        if (until != null && now < until) {
            msg(p, "Перезарядка: " + ((until - now) / 20 + 1) + " c");
            return true;
        }
        CDS.put(key, now + ticks);
        return false;
    }

    public static void handle(EntityPlayerMP p, int action) {
        // в маске вампира клавиши удара/захвата/способности работают как способности вампира
        if (action != 0 && Vampire.active(p)) {
            Vampire.handle(p, action);
            return;
        }
        int type = StandData.get(p);
        if (type == 0) {
            msg(p, "У вас нет стенда");
            return;
        }
        UUID id = p.getUniqueID();
        EntityStandHand hand = HANDS.get(id);
        if (hand != null && (hand.isDead || hand.world != p.world)) {
            HANDS.remove(id);
            hand = null;
        }

        if (action == 0) {
            if (hand != null) {
                hand.setDead();
                HANDS.remove(id);
            } else {
                hand = new EntityStandHand(p.world, p, type);
                p.world.spawnEntity(hand);
                HANDS.put(id, hand);
            }
            return;
        }
        if (hand == null) {
            msg(p, "Сначала вызовите стенд");
            return;
        }
        switch (action) {
            case 1:
                hand.punch(p);
                break;
            case 2:
                if (type == StandData.KILLER_QUEEN) KillerQueen.ability(p, hand);
                else if (type == StandData.STAR_PLATINUM) TimeStop.toggle(p);
                else if (type == StandData.GOLD_EXPERIENCE) GoldExperience.shoot(p, hand);
                else if (type == StandData.STICKY_FINGERS) StickyFingers.ability(p);
                break;
            case 3:
                hand.grab(p);
                break;
            default:
        }
    }
}
