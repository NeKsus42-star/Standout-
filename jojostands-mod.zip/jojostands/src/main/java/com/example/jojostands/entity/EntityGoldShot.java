package com.example.jojostands.entity;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.projectile.EntityThrowable;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.world.World;

/** Выстрел Gold Experience: попал - урон, промах - появляется рыба. */
public class EntityGoldShot extends EntityThrowable {
    public EntityGoldShot(World w) {
        super(w);
    }

    public EntityGoldShot(World w, EntityLivingBase thrower) {
        super(w, thrower);
    }

    @Override
    protected float getGravityVelocity() {
        return 0.0F;
    }

    @Override
    public void onUpdate() {
        super.onUpdate();
        if (world.isRemote) {
            world.spawnParticle(EnumParticleTypes.FLAME, posX, posY, posZ, 0, 0, 0);
        } else if (!isDead && ticksExisted > 25) {
            EntityGoldFish.summon(world, posX, posY, posZ, getThrower());
            setDead();
        }
    }

    @Override
    protected void onImpact(RayTraceResult r) {
        if (world.isRemote) return;
        if (r.entityHit != null) {
            r.entityHit.attackEntityFrom(DamageSource.causeThrownDamage(this, getThrower()), 9.0F);
        } else {
            EntityGoldFish.summon(world, r.hitVec.x, r.hitVec.y, r.hitVec.z, getThrower());
        }
        setDead();
    }
}
