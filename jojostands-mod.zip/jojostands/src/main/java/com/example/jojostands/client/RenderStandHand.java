package com.example.jojostands.client;

import com.example.jojostands.JojoStands;
import com.example.jojostands.StandData;
import com.example.jojostands.entity.EntityStandHand;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;

public class RenderStandHand extends Render<EntityStandHand> {
    private static final ResourceLocation[] TEX = {
            tex("stand_killerqueen"), tex("stand_killerqueen"), tex("stand_starplatinum"), tex("stand_goldexperience"),
            tex("stand_stickyfingers"), tex("stand_killerqueen"), tex("stand_anubis")};
    private static final ResourceLocation WATER = new ResourceLocation(JojoStands.MODID, "textures/entity/water_cube.png");
    private final ModelStand model = new ModelStand();

    private static ResourceLocation tex(String n) {
        return new ResourceLocation(JojoStands.MODID, "textures/entity/" + n + ".png");
    }

    public RenderStandHand(RenderManager m) {
        super(m);
    }

    @Override
    public void doRender(EntityStandHand e, double x, double y, double z, float yaw, float pt) {
        if (e.getStandType() == StandData.GEB) {
            renderGeb(e, x, y, z, pt);
            return;
        }
        float ry = e.prevRotationYaw + MathHelper.wrapDegrees(e.rotationYaw - e.prevRotationYaw) * pt;
        float age = e.ticksExisted + pt;
        float bob = 0.12F + MathHelper.sin(age * 0.1F) * 0.05F; // стенд парит

        GlStateManager.pushMatrix();
        GlStateManager.translate(x, y + bob, z);
        GlStateManager.rotate(180.0F - ry, 0.0F, 1.0F, 0.0F);
        GlStateManager.enableRescaleNormal();
        GlStateManager.scale(-1.0F, -1.0F, 1.0F);
        GlStateManager.translate(0.0F, -1.501F, 0.0F);
        bindEntityTexture(e);
        model.render(e, 0.0F, 0.0F, age, 0.0F, 0.0F, 0.0625F);
        GlStateManager.disableRescaleNormal();
        GlStateManager.popMatrix();
        super.doRender(e, x, y, z, yaw, pt);
    }

    /** Geb: кубы воды кружат вокруг игрока; в форме воды - один большой водяной блок. */
    private void renderGeb(EntityStandHand e, double x, double y, double z, float pt) {
        bindTexture(WATER);
        CubeRender.begin();
        GlStateManager.pushMatrix();
        GlStateManager.translate(x, y, z);
        if (e.isForm()) {
            GlStateManager.translate(0.0F, 0.95F, 0.0F);
            GlStateManager.scale(1.0F, 1.9F, 1.0F);
            CubeRender.draw(0.45F, 0.9F, 0.95F, 1.0F, 0.85F);
        } else {
            int n = e.getCharges();
            float t = e.ticksExisted + pt;
            for (int i = 0; i < n; i++) {
                double ang = t * 0.12 + i * (2 * Math.PI / Math.max(1, n));
                double yy = 0.9 + Math.sin(t * 0.08 + i) * 0.35;
                GlStateManager.pushMatrix();
                GlStateManager.translate(Math.cos(ang) * 1.3, yy, Math.sin(ang) * 1.3);
                GlStateManager.rotate(t * 4.0F + i * 30.0F, 0.0F, 1.0F, 0.0F);
                CubeRender.draw(0.16F, 1.0F, 1.0F, 1.0F, 0.9F);
                GlStateManager.popMatrix();
            }
        }
        GlStateManager.popMatrix();
        CubeRender.end();
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityStandHand e) {
        return TEX[MathHelper.clamp(e.getStandType(), 0, 6)];
    }
}
