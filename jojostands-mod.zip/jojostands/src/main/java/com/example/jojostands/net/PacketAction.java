package com.example.jojostands.net;

import com.example.jojostands.StandLogic;
import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

/** 0 = вызвать/убрать, 1 = удар, 2 = способность, 3 = взять предмет */
public class PacketAction implements IMessage {
    public int action;

    public PacketAction() {}

    public PacketAction(int action) {
        this.action = action;
    }

    @Override
    public void fromBytes(ByteBuf buf) {
        action = buf.readByte();
    }

    @Override
    public void toBytes(ByteBuf buf) {
        buf.writeByte(action);
    }

    public static class Handler implements IMessageHandler<PacketAction, IMessage> {
        @Override
        public IMessage onMessage(PacketAction msg, MessageContext ctx) {
            final EntityPlayerMP p = ctx.getServerHandler().player;
            final int action = msg.action;
            p.getServerWorld().addScheduledTask(() -> {
                StandLogic.handle(p, action);
            });
            return null;
        }
    }
}
