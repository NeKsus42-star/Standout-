package com.example.jojostands;

import java.util.Random;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.item.Item;

/** Плодовый блок: при разрушении падает особый фрукт. */
public class BlockFruit extends BlockSimple {
    public BlockFruit() {
        super("fruit_block", Material.WOOD, 1.0F, SoundType.WOOD);
    }

    @Override
    public Item getItemDropped(IBlockState state, Random rand, int fortune) {
        return ModContent.SPECIAL_FRUIT;
    }

    @Override
    public int quantityDropped(Random random) {
        return 1;
    }
}
