package com.example.jojostands;

import com.example.jojostands.entity.EntityStandHand;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

/** 1-е нажатие: красная метка на месте/мобе. 2-е нажатие: взрыв силой как у динамита (4.0). */
public class KillerQueen {
    private static final float POWER = 4.0F; // TNT
    private static final int MAX_AGE = 20 * 90;

    private static class Mark {
        Vec3d pos;
        UUID entity;
        int dim;
        int age;
    }

    private static final Map<UUID, Mark> MARKS = new HashMap<>();

    public static void ability(EntityPlayerMP p, EntityStandHand hand) {
        Mark m = MARKS.get(p.getUniqueID());
        if (m == null) {
            RayTraceResult r = StandUtil.trace(p, 40.0, e -> e instanceof EntityLivingBase || e instanceof EntityItem);
            if (r == null) {
                StandLogic.msg(p, "Метку некуда поставить");
                return;
            }
            m = new Mark();
            m.dim = p.world.provider.getDimension();
            if (r.entityHit != null) {
                m.entity = r.entityHit.getUniqueID();
                m.pos = StandUtil.center(r.entityHit);
            } else {
                m.pos = r.hitVec;
            }
            MARKS.put(p.getUniqueID(), m);
            hand.gesture(m.pos);
            StandLogic.msg(p, "Метка установлена. Нажмите ещё раз - взрыв");
        } else {
            MARKS.remove(p.getUniqueID());
            WorldServer ws = p.getServer() != null ? p.getServer().getWorld(m.dim) : null;
            if (ws == null) return;
            ws.createExplosion(p, m.pos.x, m.pos.y, m.pos.z, POWER, true);
        }
    }

    /** Красный след, который остаётся на месте метки. */
    public static void tick(World w) {
        if (MARKS.isEmpty() || !(w instanceof WorldServer)) return;
        WorldServer ws = (WorldServer) w;
        int dim = w.provider.getDimension();
        Iterator<Mark> it = MARKS.values().iterator();
        while (it.hasNext()) {
            Mark m = it.next();
            if (m.dim != dim) continue;
            if (++m.age > MAX_AGE) {
                it.remove();
                continue;
            }
            if (m.entity != null) {
                Entity en = ws.getEntityFromUuid(m.entity);
                if (en == null || en.isDead) {
                    it.remove();
                    continue;
                }
                m.pos = StandUtil.center(en);
            }
            if (m.age % 2 == 0) {
                ws.spawnParticle(EnumParticleTypes.REDSTONE, m.pos.x, m.pos.y, m.pos.z, 5, 0.3, 0.3, 0.3, 0.0);
            }
        }
    }
}
