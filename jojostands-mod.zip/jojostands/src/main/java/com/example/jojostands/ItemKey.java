package com.example.jojostands;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;

/** Ключ: нужен в руке для способности Mr. President. Модель рисуется из файла key_mesh.json. */
public class ItemKey extends Item {
    public ItemKey() {
        setRegistryName(JojoStands.MODID, "key");
        setTranslationKey("key");
        setCreativeTab(CreativeTabs.TOOLS);
        setMaxStackSize(1);
    }
}
