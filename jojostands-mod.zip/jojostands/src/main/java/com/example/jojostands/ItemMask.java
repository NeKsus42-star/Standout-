package com.example.jojostands;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemArmor;

public class ItemMask extends ItemArmor {
    public ItemMask(ItemArmor.ArmorMaterial material, String name) {
        super(material, 0, EntityEquipmentSlot.HEAD);
        setRegistryName(JojoStands.MODID, name);
        setTranslationKey(name);
        setCreativeTab(CreativeTabs.COMBAT);
    }
}
