package com.example.jojostands;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class ItemMask extends ItemArmor {
    public ItemMask(ItemArmor.ArmorMaterial material, String name) {
        super(material, 0, EntityEquipmentSlot.HEAD);
        setRegistryName(JojoStands.MODID, name);
        setTranslationKey(name);
        setCreativeTab(CreativeTabs.COMBAT);
    }

    /** На персонаже: только лицевая пластина с шипами у висков. */
    @SideOnly(Side.CLIENT)
    @Override
    public net.minecraft.client.model.ModelBiped getArmorModel(EntityLivingBase entity, ItemStack stack,
                                                               EntityEquipmentSlot slot, net.minecraft.client.model.ModelBiped base) {
        return com.example.jojostands.client.MaskModels.get();
    }
}
