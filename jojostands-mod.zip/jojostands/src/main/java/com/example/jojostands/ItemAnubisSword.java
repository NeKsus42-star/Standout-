package com.example.jojostands;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemSword;

/** Меч Анубиса (неломаемый). */
public class ItemAnubisSword extends ItemSword {
    public ItemAnubisSword(ToolMaterial material) {
        super(material);
        setRegistryName(JojoStands.MODID, "anubis_sword");
        setTranslationKey("anubis_sword");
        setCreativeTab(CreativeTabs.COMBAT);
    }
}
