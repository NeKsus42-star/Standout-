package com.example.jojostands;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;

/** Съев фрукт, вы теряете стенд (можно получить новый стрелой). */
public class ItemSpecialFruit extends ItemFood {
    public ItemSpecialFruit() {
        super(4, 0.3F, false);
        setRegistryName(JojoStands.MODID, "special_fruit");
        setTranslationKey("special_fruit");
        setCreativeTab(CreativeTabs.FOOD);
        setAlwaysEdible();
    }

    @Override
    protected void onFoodEaten(ItemStack stack, World world, EntityPlayer player) {
        super.onFoodEaten(stack, world, player);
        if (!world.isRemote) {
            StandData.set(player, 0);
            player.sendMessage(new TextComponentString("Ваш стенд сброшен"));
        }
    }
}
