# JoJo Stands (Forge 1.12.2)

Сборка: Java 8 + Gradle 4.9 (нужен gradle wrapper от 1.12.2 MDK):
1. Скопируйте gradle/, gradlew, gradlew.bat из Forge MDK 1.12.2 (14.23.5.2860) в эту папку.
2. `gradlew setupDecompWorkspace` -> `gradlew build` -> jar в build/libs.

Текстуры метеорита, осколка и стрелы уже вставлены.
Текстуры рук/рыбы (textures/entity/*.png) - временные заглушки.
